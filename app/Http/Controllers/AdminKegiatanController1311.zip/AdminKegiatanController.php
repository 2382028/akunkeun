<?php

namespace App\Http\Controllers;


use Carbon\Carbon; 
use Illuminate\Support\Facades\Storage;
use App\Models\Dokumen;
use App\Http\Controllers\Controller;
use App\Models\Data_perjadinkegiatan;
use App\Models\Mobilitas_perjadinkegiatan;
use App\Models\Kendaraan;
use App\Models\Fasilitas;
use App\Models\Versi;
use App\Models\Keuangan_perjadinkegiatan;
use App\Models\Laporan_perjadinkegiatan;
use App\Models\Operasional;
use App\Models\Perangkat_acara;
use App\Models\Ref_sbm;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use PDF;

class AdminKegiatanController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index($status = 'pengajuan')
    {
        $mobilitas = DB::table('mobilitas_perjadinkegiatans')
                        ->join('data_perjadinkegiatans', 'mobilitas_perjadinkegiatans.data_perjadinkegiatan', '=', 'data_perjadinkegiatans.id')
                        ->join('versis', 'mobilitas_perjadinkegiatans.versi_id', '=', 'versis.id')
                        ->select('data_perjadinkegiatans.id as idKegiatan', 'mobilitas_perjadinkegiatans.id as idMobilitas','data_perjadinkegiatans.nama_kegiatan', 'mobilitas_perjadinkegiatans.tujuan_penggunaan', 'mobilitas_perjadinkegiatans.tgl_mulai', 'mobilitas_perjadinkegiatans.status')
                        ->where('data_perjadinkegiatans.versi_id', session('versi'))
                        ->where('mobilitas_perjadinkegiatans.status', $status)
                        ->whereNotNull('data_perjadinkegiatans.is_acceptBMN')
                        ->get();
        return view('admin.kegiatan.mobilitas.index', [
            'title' => 'Mobilitas Kegiatan',
            'mobilitass' => $mobilitas
        ]);
    }

    public function HKTIndex($status = 'pengajuan')
    {
        // Ambil data kegiatan dan dokumen yang relevan
        $kegiatan = DB::table('data_perjadinkegiatans')
        ->join('laporan_perjadinkegiatans', 'data_perjadinkegiatans.id', '=', 'laporan_perjadinkegiatans.data_perjadin_kegiatan')
        ->leftJoin('surtug_perjadinkegiatans', 'data_perjadinkegiatans.id', '=', 'surtug_perjadinkegiatans.data_perjadin_kegiatan') // Join dengan tabel surtug_perjadinkegiatans
        ->leftJoin('pegawais', 'data_perjadinkegiatans.id_pengaju', '=', 'pegawais.id') // Left join ke pegawais
        ->leftJoin('non_pegawais', 'data_perjadinkegiatans.id_pengaju', '=', 'non_pegawais.id') // Left join ke non_pegawais
        ->leftJoin('administrators', 'data_perjadinkegiatans.id_pengaju', '=', 'administrators.id') // Left join ke administrators
        ->where('data_perjadinkegiatans.is_acceptHKT', $status)
        ->where('data_perjadinkegiatans.versi_id', session('versi'))
        ->whereNotNull('laporan_perjadinkegiatans.file')
        ->select(
            'data_perjadinkegiatans.*', 
            'laporan_perjadinkegiatans.file',
            'surtug_perjadinkegiatans.nomor_surat',      // Kolom dari surtug_perjadinkegiatans
            'surtug_perjadinkegiatans.perihal',
            'surtug_perjadinkegiatans.paragraf_1',
            'surtug_perjadinkegiatans.paragraf_2',
            'surtug_perjadinkegiatans.paragraf_3',
            'surtug_perjadinkegiatans.tgl_surat_dibuat',
            DB::raw('COALESCE(CONCAT("(Admin) ", administrators.username), pegawais.nama_lengkap, non_pegawais.nama_lengkap, "Tidak ditemukan") as nama_pengaju')
        
        )
        ->get();
    
            
            $kegiatanIds = $kegiatan->pluck('id');
            // Ambil semua id_kegiatan dari kegiatan

        // Ambil id untuk HKT selesai
        $HKTselesaiId = DB::table('data_perjadinkegiatans')
            ->where('is_acceptHKT', 'selesai')
            ->pluck('id');

        // Ambil id perjadinkegiatan dari surtug_perjadinkegiatans
        $surtugExist = DB::table('surtug_perjadinkegiatans')
            ->whereIn('data_perjadin_kegiatan', $kegiatanIds)
            ->pluck('data_perjadin_kegiatan');

        // Tambahkan dokumen ke setiap item kegiatan
        foreach ($kegiatan as $info) {
            // Konversi tanggal ke dalam objek Carbon untuk perhitungan
            $tglMulai = \Carbon\Carbon::parse($info->tgl_mulai)->startOfDay();
            $tglSelesai = \Carbon\Carbon::parse($info->tgl_selesai)->endOfDay();

            // Hitung selisih hari
            $jumlahHari = $tglMulai->diffInDays($tglSelesai) + 1;

            // Tambahkan jumlah hari ke objek $info
            $info->jumlah_hari = $jumlahHari;

            // Ambil dokumen yang sesuai untuk setiap perjadin
            $info->dokumen = DB::table('laporan_perjadinkegiatans')
                ->where('data_perjadin_kegiatan', $info->id)
                ->get();
        }

        return view('admin.kegiatan.HKT.index', [
            'title' => 'HKT Perjadin Kegiatan',
            'kegiatans' => $kegiatan,
            'surtugs' => DB::table('surtug_perjadinkegiatans')->get(), // Mengambil semua data dari surtug_perjadinkegiatans
            'surtugExist' => $surtugExist,
        ]);
    }
    public function detail_kegiatan_HKT($id)
    {
        $pesertaPegawais = DB::table('perangkat_acaras')
            ->join('pegawais', 'perangkat_acaras.pegawai_id', '=', 'pegawais.id')
            ->select('pegawais.nama_lengkap', 'pegawais.pangkat', 'pegawais.golongan', 'perangkat_acaras.posisi')
            ->where('perangkat_acaras.data_perjadin_kegiatan', $id)
            ->where('perangkat_acaras.posisi', '!=', 'Supir')
            ->get();
        $pesertaNonPegawais = DB::table('perangkat_acaras')
            ->join('non_pegawais', 'perangkat_acaras.non_pegawai_id', '=', 'non_pegawais.id')
            ->select('non_pegawais.nama_lengkap', 'non_pegawais.pangkat', 'non_pegawais.golongan', 'perangkat_acaras.posisi')
            ->where('perangkat_acaras.data_perjadin_kegiatan', $id)
            ->where('perangkat_acaras.posisi', '!=', 'Supir')
            ->get();
        $pengemudi =  DB::table('perangkat_acaras')
            ->join('pegawais', 'perangkat_acaras.pegawai_id', '=', 'pegawais.id')
            ->select('pegawais.nama_lengkap', 'pegawais.pangkat', 'pegawais.golongan', 'perangkat_acaras.posisi')
            ->where('perangkat_acaras.data_perjadin_kegiatan', $id)
            ->where('perangkat_acaras.posisi', 'Supir')
            ->get();
        $pengemudi =  DB::table('perangkat_acaras')
            ->join('pegawais', 'perangkat_acaras.pegawai_id', '=', 'pegawais.id')
            ->select('pegawais.nama_lengkap', 'pegawais.pangkat', 'pegawais.golongan', 'perangkat_acaras.posisi')
            ->where('perangkat_acaras.data_perjadin_kegiatan', $id)
            ->where('perangkat_acaras.posisi', 'Supir')
            ->get();
        $dokumen =  DB::table('laporan_perjadinkegiatans')
            ->select('*')
            ->where('laporan_perjadinkegiatans.data_perjadin_kegiatan', $id)
            ->get();

        return view('admin.kegiatan.HKT.detail', [
            'title' => 'Pengajuan Surtug',
            'pesertaPegawais' => $pesertaPegawais,
            'pesertaNonPegawais' => $pesertaNonPegawais,
            'dokumen' => $dokumen,
            'kegiatan' => Data_perjadinkegiatan::find($id),
            'mobilitass' => Mobilitas_perjadinkegiatan::where('data_perjadinkegiatan', $id)->get(),
            'pengemudis' => $pengemudi,
        ]);
    }

    

    // ini function untuk edit saat di button edit di index.blade

    public function detail_surtug_kegiatan_HKT_edit($id)
    {
        $surat = DB::table('surtug_perjadinkegiatans')
            ->join('data_perjadinkegiatans', 'surtug_perjadinkegiatans.data_perjadin_kegiatan', '=', 'data_perjadinkegiatans.id')
            ->select('surtug_perjadinkegiatans.nomor_surat', 'surtug_perjadinkegiatans.perihal', 'surtug_perjadinkegiatans.paragraf_1', 'surtug_perjadinkegiatans.paragraf_2', 'surtug_perjadinkegiatans.paragraf_3')
            ->where('surtug_perjadinkegiatans.data_perjadin_kegiatan', $id)
            ->get();

        return view('admin.kegiatan.HKT.edit_surtug', [
            'title' => 'Edit Surat Tugas',
            'kegiatan' => Data_perjadinkegiatan::find($id),
            'surtugs' => $surat,
        ]);
    }

    public function surtug_kegiatan_HKT($id)
    {
        $surat = DB::table('surtug_perjadinkegiatans')
            ->join('data_perjadinkegiatans', 'surtug_perjadinkegiatans.data_perjadin_kegiatan', '=', 'data_perjadinkegiatans.id')
            ->select('surtug_perjadinkegiatans.nomor_surat', 'surtug_perjadinkegiatans.perihal', 'surtug_perjadinkegiatans.paragraf_1', 'surtug_perjadinkegiatans.paragraf_2', 'surtug_perjadinkegiatans.paragraf_3')
            ->where('surtug_perjadinkegiatans.data_perjadin_kegiatan', $id)
            ->get();

        return view('admin.kegiatan.HKT.surtug', [
            'title' => 'Pembuatan Surat Tugas',
            'kegiatan' => Data_perjadinkegiatan::find($id),
            'surtugs' => $surat,

        ]);
    }

    public function detail_surtug_kegiatan_HKT($id)
    {
        $pesertaPegawais = DB::table('perangkat_acaras')
            ->join('pegawais', 'perangkat_acaras.pegawai_id', '=', 'pegawais.id')
            ->join('jabatans', 'pegawais.jabatan_id', '=', 'jabatans.id')
            ->select('pegawais.NIP_NIK','pegawais.nama_lengkap', 'pegawais.pangkat', 'pegawais.golongan', 'perangkat_acaras.posisi', 'pegawais.NIP_NIK', 'jabatans.nama_jabatan')
            ->where('perangkat_acaras.data_perjadin_kegiatan', $id)
            ->where(function ($query) {
                $query->where('perangkat_acaras.posisi', '!=', 'Supir')
                    ->orWhere(function ($query) {
                        $query->where('perangkat_acaras.posisi', '=', 'Supir')
                            ->whereNotExists(function ($query) {
                                $query->select(DB::raw(1))
                                    ->from('perangkat_acaras as dp2')
                                    ->whereColumn('dp2.pegawai_id', 'perangkat_acaras.pegawai_id')
                                    ->where('dp2.posisi', '!=', 'Supir');
                            });
                    });
            })
            ->orderBy('perangkat_acaras.posisi', 'asc')
            ->get();


        $pesertaNonPegawais = DB::table('perangkat_acaras')
            ->join('non_pegawais', 'perangkat_acaras.non_pegawai_id', '=', 'non_pegawais.id')
            ->select('non_pegawais.NIP_NIK','non_pegawais.nama_lengkap', 'non_pegawais.pangkat', 'non_pegawais.golongan', 'perangkat_acaras.posisi')
            ->where('perangkat_acaras.data_perjadin_kegiatan', $id)
            ->get();
        $pengemudi = DB::table('pegawais')
            ->join('jabatans', 'pegawais.jabatan_id', '=', 'jabatans.id')
            ->join('peminjaman_kendaraan_dinas', 'peminjaman_kendaraan_dinas.pegawai_id', '=', 'pegawais.id')
            ->join('mobilitas_perjadinkegiatans', 'peminjaman_kendaraan_dinas.mobilitas_perjadinkegiatan', '=', 'mobilitas_perjadinkegiatans.id')
            ->select('pegawais.id', 'pegawais.nama_lengkap', 'jabatans.nama_jabatan', 'pegawais.NIP_NIK', 'pegawais.pangkat', 'pegawais.golongan')
            ->where('jabatans.nama_jabatan', 'Pengemudi')
            ->where('peminjaman_kendaraan_dinas.mobilitas_perjadinkegiatan', $id)
            ->get();
        $surat = DB::table('surtug_perjadinkegiatans')
            ->join('data_perjadinkegiatans', 'surtug_perjadinkegiatans.data_perjadin_kegiatan', '=', 'data_perjadinkegiatans.id')
            ->select('surtug_perjadinkegiatans.nomor_surat', 'surtug_perjadinkegiatans.perihal', 'surtug_perjadinkegiatans.paragraf_1', 'surtug_perjadinkegiatans.paragraf_2', 'surtug_perjadinkegiatans.paragraf_3')
            ->where('surtug_perjadinkegiatans.data_perjadin_kegiatan', $id)
            ->get();
        return view('admin.kegiatan.HKT.preview_surtug', [
            'title' => 'Pembuatan Surat Tugas',
            'pesertaPegawais' => $pesertaPegawais,
            'pesertaNonPegawais' => $pesertaNonPegawais,
            'kegiatan' => Data_perjadinkegiatan::find($id),
            'pengemudis' => $pengemudi,
            'surtugs' => $surat
        ]);
    }

    public function ConvertSurtug($id)
    {
        if (!$id) {
            // Handle jika data tidak ditemukan
            dd('Data tidak ditemukan.');
        }

        $pesertaPegawais = DB::table('perangkat_acaras')
            ->join('pegawais', 'perangkat_acaras.pegawai_id', '=', 'pegawais.id')
            ->join('jabatans', 'pegawais.jabatan_id', '=', 'jabatans.id')
            ->select('pegawais.NIP_NIK','pegawais.nama_lengkap', 'pegawais.pangkat', 'pegawais.golongan', 'perangkat_acaras.posisi', 'pegawais.NIP_NIK', 'jabatans.nama_jabatan')
            ->where('perangkat_acaras.data_perjadin_kegiatan', $id)
            ->where(function ($query) {
                $query->where('perangkat_acaras.posisi', '!=', 'Supir')
                    ->orWhere(function ($query) {
                        $query->where('perangkat_acaras.posisi', '=', 'Supir')
                            ->whereNotExists(function ($query) {
                                $query->select(DB::raw(1))
                                    ->from('perangkat_acaras as dp2')
                                    ->whereColumn('dp2.pegawai_id', 'perangkat_acaras.pegawai_id')
                                    ->where('dp2.posisi', '!=', 'Supir');
                            });
                    });
            })
            ->orderBy('perangkat_acaras.posisi', 'asc')
            ->get();


        $pesertaNonPegawais = DB::table('perangkat_acaras')
            ->join('non_pegawais', 'perangkat_acaras.non_pegawai_id', '=', 'non_pegawais.id')
            ->select('non_pegawais.NIP_NIK','non_pegawais.nama_lengkap', 'non_pegawais.pangkat', 'non_pegawais.golongan', 'perangkat_acaras.posisi')
            ->where('perangkat_acaras.data_perjadin_kegiatan', $id)
            ->get();
        $pengemudi = DB::table('pegawais')
            ->join('jabatans', 'pegawais.jabatan_id', '=', 'jabatans.id')
            ->join('peminjaman_kendaraan_dinas', 'peminjaman_kendaraan_dinas.pegawai_id', '=', 'pegawais.id')
            ->join('mobilitas_perjadinkegiatans', 'peminjaman_kendaraan_dinas.info_perjadinlangsung', '=', 'mobilitas_perjadinkegiatans.id')
            ->select('pegawais.id', 'pegawais.nama_lengkap', 'jabatans.nama_jabatan', 'pegawais.NIP_NIK', 'pegawais.pangkat', 'pegawais.golongan')
            ->where('jabatans.nama_jabatan', 'Pengemudi')
            ->where('peminjaman_kendaraan_dinas.mobilitas_perjadinkegiatan', $id)
            ->get();
        $surat = DB::table('surtug_perjadinkegiatans')
            ->join('data_perjadinkegiatans', 'surtug_perjadinkegiatans.data_perjadin_kegiatan', '=', 'data_perjadinkegiatans.id')
            ->select('surtug_perjadinkegiatans.nomor_surat', 'surtug_perjadinkegiatans.perihal', 'surtug_perjadinkegiatans.paragraf_1', 'surtug_perjadinkegiatans.paragraf_2', 'surtug_perjadinkegiatans.paragraf_3')
            ->where('surtug_perjadinkegiatans.data_perjadin_kegiatan', $id)
            ->get();

        $datas = [
            'pesertaPegawais' => $pesertaPegawais,
            'pesertaNonPegawais' => $pesertaNonPegawais,
            'kegiatan' => Data_perjadinkegiatan::find($id),
            'surtugs' => $surat,
        ];
        // Lakukan proses pembuatan file PDF
        $pdf = PDF::loadView('admin.kegiatan.HKT.surtug_detail', compact('datas'));
        $pdf->setPaper('A4', 'portrait');

        // Simpan file PDF ke penyimpanan
        $filePath = $pdf->output();
        Storage::disk('public')->put('dokumen-kegiatans/surtugKegiatan.pdf', $filePath);

        // Stream file PDF ke browser
        return $pdf->stream('surtugKegiatan.pdf');
    }

    public function storeSurtug(Request $request)
    {
        // Validasi input yang diterima
        $validatedData = $request->validate([
            'perihal' => 'nullable|string',
            'paragraf1' => 'nullable|string',
            'paragraf2' => 'nullable|string',
            'paragraf3' => 'nullable|string',
        ]);

        $id = $request->input('idKegiatan'); // 'id' sesuai dengan parameter dalam URL

        $exists = DB::table('surtug_perjadinkegiatans')->where('data_perjadin_kegiatan', $id)->exists();

        if ($exists) {
            return redirect()->back()->with('error', 'Surat Tugas sudah ada untuk perjalanan dinas ini.');
        }

        DB::table('surtug_perjadinkegiatans')->Insert([
            'data_perjadin_kegiatan' => $request->idKegiatan,
            'perihal' => $request->perihal,
            'paragraf_1' => $request->paragraf1,
            'paragraf_2' => $request->paragraf2,
            'paragraf_3' => $request->paragraf3,
        ]);
        $id = $request->idKegiatan;
        return redirect()->route('surtug-detail-HKT-kegiatan', ['id' => $id])->with('success', 'Surat Tugas Berhasil Ditambahkan!');
    }

    public function StoreSurtugPDF(Request $request)
    {
        $id = $request->input('idKegiatan'); // 'id' sesuai dengan parameter dalam URL
        if (!$id) {
            dd('Data tidak ditemukan.');
        }

        $pesertaPegawais = DB::table('perangkat_acaras')
            ->join('pegawais', 'perangkat_acaras.pegawai_id', '=', 'pegawais.id')
            ->join('jabatans', 'pegawais.jabatan_id', '=', 'jabatans.id')
            ->select('pegawais.nama_lengkap', 'pegawais.pangkat', 'pegawais.golongan', 'perangkat_acaras.posisi', 'pegawais.NIP_NIK','jabatans.nama_jabatan')
            ->where('perangkat_acaras.data_perjadin_kegiatan', $id)
            ->get();

        $pesertaNonPegawais = DB::table('perangkat_acaras')
            ->join('non_pegawais', 'perangkat_acaras.non_pegawai_id', '=', 'non_pegawais.id')
            ->select('non_pegawais.nama_lengkap', 'non_pegawais.pangkat', 'non_pegawais.golongan', 'perangkat_acaras.posisi')
            ->where('perangkat_acaras.data_perjadin_kegiatan', $id)
            ->get();

        $pengemudi = DB::table('pegawais')
            ->join('jabatans', 'pegawais.jabatan_id', '=', 'jabatans.id')
            ->join('peminjaman_kendaraan_dinas', 'peminjaman_kendaraan_dinas.pegawai_id', '=', 'pegawais.id')
            ->join('mobilitas_perjadinkegiatans', 'peminjaman_kendaraan_dinas.mobilitas_perjadinkegiatan', '=', 'mobilitas_perjadinkegiatans.id')
            ->select('pegawais.id', 'pegawais.nama_lengkap', 'jabatans.nama_jabatan', 'pegawais.NIP_NIK', 'pegawais.pangkat', 'pegawais.golongan')
            ->where('jabatans.nama_jabatan', 'Pengemudi')
            ->where('peminjaman_kendaraan_dinas.mobilitas_perjadinkegiatan', $id)
            ->get();

        $surat = DB::table('surtug_perjadinkegiatans')
            ->join('data_perjadinkegiatans', 'surtug_perjadinkegiatans.data_perjadin_kegiatan', '=', 'data_perjadinkegiatans.id')
            ->select('surtug_perjadinkegiatans.nomor_surat', 'surtug_perjadinkegiatans.perihal', 'surtug_perjadinkegiatans.paragraf_1', 'surtug_perjadinkegiatans.paragraf_2', 'surtug_perjadinkegiatans.paragraf_3')
            ->where('surtug_perjadinkegiatans.data_perjadin_kegiatan', $id)
            ->get();

        $datas = [
            'pesertaPegawais' => $pesertaPegawais,
            'pesertaNonPegawais' => $pesertaNonPegawais,
            'kegiatan' => Data_perjadinkegiatan::find($id),
            'pengemudis' => $pengemudi,
            'surtugs' => $surat,
        ];

        // Lakukan proses pembuatan file PDF
        $pdf = PDF::loadView('admin.kegiatan.HKT.surtug_detail', compact('datas'));
        $pdf->setPaper('A4', 'portrait');

        // Simpan file PDF ke penyimpanan
        $filePath = $pdf->output();
        Storage::disk('public')->put('dokumen-kegiatans/surtugKegiatan.pdf', $filePath);

        // Simpan data ke tabel 'dokumens'
        DB::table('data_perjadinkegiatans')
            ->where('id', $id)
            ->update([
                'surat_tugas' => 'dokumen-kegiatans/surtugKegiatan.pdf',
                'is_acceptHKT' => 'pengajuan',
                'created_at' => now()->format('Y-m-d H:i:s'),
                'updated_at' => now()->format('Y-m-d H:i:s'),
            ]);

        return redirect()->route('HKT-kegiatan', ['status' => 'pengajuan'])->with('success', 'Surat Tugas telah berhasil dibuat!');
    }

    public function UpdateSurtug(Request $request)
    {


        $validationData = $request->validate([
            'surat_tugas_update' => 'required|mimes:pdf|file|max:2048',
        ]);

        if (empty($validationData)) {
            dd('Gagal Upload');
        }

        $id = $request->input('idKegiatanUpdate'); // 'id' sesuai dengan parameter dalam URL
        if (!$id) {
            dd('Data tidak ditemukan.');
        }
        $kegiatan = DB::table('data_perjadinkegiatans')->where('id', $id)->first();
        if (!$kegiatan) {
            dd('Data tidak ditemukan.');
        }
        DB::table('data_perjadinkegiatans')
            ->where('id', $id)
            ->update([
                'surat_tugas' => $validationData['surat_tugas_update'] = $request->file('surat_tugas_update')->store('dokumen-kegiatans', 'public'),
                'updated_at' => now()->format('Y-m-d H:i:s'),
            ]);
        DB::table('data_perjadinkegiatans')
            ->where('id', $id)
            ->update([
                'kode_surat_tugas' => $request->nomor_surtug_update,
                'updated_at' => now()->format('Y-m-d H:i:s'),
            ]);
        DB::table('surtug_perjadinkegiatans')
            ->where('data_perjadin_kegiatan', $id)
            ->update([
                'nomor_surat' => $request->nomor_surtug_update,
                'tgl_surat_dibuat' => $request->tgl_dibuat_update,
                'updated_at' => now()->format('Y-m-d H:i:s'),
            ]);


        return redirect()->route('HKT-kegiatan', ['status' => 'selesai'])->with('success', 'Surat Tugas telah berhasil di Update!');
    }

    public function UploadSurtug(Request $request)
    {



        $validationData = $request->validate([
            'surat_tugas' => 'required|mimes:pdf|file|max:2048',
        ]);

        if (empty($validationData)) {
            dd('Gagal Upload');
        }

        $id = $request->input('idKegiatan'); // 'id' sesuai dengan parameter dalam URL
        if (!$id) {
            dd('Data tidak ditemukan.');
        }
        $perjadin = DB::table('data_perjadinkegiatans')->where('id', $id)->first();
        if (!$perjadin) {
            dd('Data tidak ditemukan.');
        }
        $pengusul = DB::table('pegawais')
            ->join('data_perjadinkegiatans', 'pegawais.id', '=', 'data_perjadinkegiatans.id_pengaju')
            ->select('data_perjadinkegiatans.id_pengaju', 'pegawais.nama_lengkap')    
            ->where('data_perjadinkegiatans.id',$id)
            ->first(); 

      
        DB::table('data_perjadinkegiatans')
            ->where('id', $id)
            ->whereNull('is_acceptKeu')
            ->update([
                'is_acceptBend' => 'approval-1',
                'status_pengajuan_detail' => 'Approval-1-Bendahara',
                'kode_surat_tugas' => $request->nomor_surtug,
                'is_acceptHKT' => 'selesai',
                'surat_tugas' => $validationData['surat_tugas'] = $request->file('surat_tugas')->store('dokumen-kegiatans', 'public'),
                'updated_at' => now()->format('Y-m-d H:i:s'),
            ]);
        DB::table('surtug_perjadinkegiatans')
            ->where('data_perjadin_kegiatan', $id)
            ->update([
                'nomor_surat' => $request->nomor_surtug,
                'tgl_surat_dibuat' => $request->tgl_dibuat,
                'created_at' => now()->format('Y-m-d H:i:s'),
                'updated_at' => now()->format('Y-m-d H:i:s'),
            ]);

            db::table('laporan_perjadinkegiatans')->insertOrIgnore([
                'nama_dokumen' => 'Surat Tugas '.$id,
                'file' => $validationData['surat_tugas'] = $request->file('surat_tugas')->store('dokumen-kegiatans', 'public'),
                'data_perjadin_kegiatan' => $id,
                'status' => 'diajukan',
                'created_at' => now()->format('Y-m-d H:i:s'),
                'updated_at' => now()->format('Y-m-d H:i:s'),
    
            ]);

        $dataNotif = [
            'id_kegiatan' => $id,
            'from' => auth('administrator')->user()->id, // ID pengguna yang mengirim
            'to' => 0, // ID pengguna yang menerima
            'role' => 'Bendahara', // Peran pengguna
            'header' => 'Usulan Perjalanan Dinas - '.$id, // Judul notifikasi
            'message' => 'Usulan oleh '.$id.' telah diverifikasi HKT dan Surtug sudah tersedia', // Isi pesan
            'route' => 'perjadin-bendahara/detail/'.$id, // Route yang dituju
            'is_read' => 0, // Status belum dibaca
            'created_at' => now()->format('Y-m-d H:i:s'), // Waktu saat dibuat
        ];
        
        // Melakukan insert ke tabel notifications
        DB::table('notifications')->insert($dataNotif);

    $dataNotifUser = [
            'id_kegiatan' => $id,
            'from' => auth('administrator')->user()->id, // ID pengguna yang mengirim
            'to' => '0', // ID pengguna yang menerima
            'role' => null, // Peran pengguna
            'header' => 'Usulan Perjadin Disetujui HKT - '.$id, // Judul notifikasi
            'message' => 'Surat Tugas untuk Perjalanan Dinas '.$id.' telah terbit, silakan menunggu Approval-1 Bendahara', // Isi pesan
            'route' => 'perjadin/riwayat/proses', // Route yang dituju
            'is_read' => 0, // Status belum dibaca
            'created_at' => now()->format('Y-m-d H:i:s'), // Waktu saat dibuat
            ];
            
    //     // Melakukan insert ke tabel notifications
        DB::table('notifications')->insert($dataNotifUser);


        return redirect()->route('HKT-kegiatan', ['status' => 'pengajuan'])->with('success', 'Surat Tugas telah berhasil di Upload!');
    }


    public function EditSurtug(Request $request)
    {
        // Validasi input yang diterima
        $validatedData = $request->validate([
            'perihal' => 'nullable|string',
            'paragraf1' => 'nullable|string',
            'paragraf2' => 'nullable|string',
            'paragraf3' => 'nullable|string',
        ]);

        $id = $request->input('idKegiatan'); // 'id' sesuai dengan parameter dalam URL
        if (!$id) {
            dd('Data tidak ditemukan.');
        }
        DB::table('surtug_perjadinkegiatans')
            ->where('data_perjadin_kegiatan', $id)
            ->update([
                'perihal' => $request->perihal,
                'paragraf_1' => $request->paragraf1,
                'paragraf_2' => $request->paragraf2,
                'paragraf_3' => $request->paragraf3,
            ]);

        return redirect()->route('surtug-detail-HKT-kegiatan', ['id' => $id])->with('success', 'Surat Tugas Berhasil Diubah!');
    }

    //

    public function assetIndex($status = 'pengajuan')
    {
        $peminjamansapras = DB::table('peminjaman_sarpras')
                        ->join('data_perjadinkegiatans', 'peminjaman_sarpras.data_perjadinkegiatan', '=', 'data_perjadinkegiatans.id')
                        ->join('pegawais', 'peminjaman_sarpras.pegawai_id', '=', 'pegawais.id')
                        ->join('assets', 'peminjaman_sarpras.asset', '=', 'assets.id')
                        ->select('data_perjadinkegiatans.id as idPeminjaman','pegawais.nama_lengkap', 'assets.nama_barang', 'peminjaman_sarpras.status')
                        ->where('peminjaman_sarpras.status', $status)
                        ->where('data_perjadinkegiatans.is_acceptAset', 'pengajuan')
                        ->where('data_perjadinkegiatans.versi_id', session('versi'))
                        ->get();
        return view('admin.kegiatan.assets.index', [
            'title' => 'Peminjaman Assets',
            'peminjamans' => $peminjamansapras,
        ]);
    }

    public function bendaharaIndex($status = 'verifikasi-1')
    {
        $kegiatans = DB::table('data_perjadinkegiatans')
                         ->where('is_acceptBend', $status)
                         ->where('versi_id', session('versi'))
                         ->get();
        return view('admin.kegiatan.bendahara.index', [
            'title' => 'Bendahara Kegiatan',
            'kegiatans' => $kegiatans
        ]);
    }

    public function keuanganIndex($status = 'verifikasi-1')
    {
        $kegiatans = DB::table('data_perjadinkegiatans')
                         ->where('is_acceptKeu', $status)
                         ->where('versi_id', session('versi'))
                         ->get();
        return view('admin.kegiatan.keuangan.index', [
            'title' => 'Keuangan Kegiatan',
            'kegiatans' => $kegiatans
        ]);
    }

    public function detail_mobilitas(Request $request, $id)
{
    $infoKegiatan = DB::table('mobilitas_perjadinkegiatans')
                ->select('data_perjadinkegiatan')
                ->where('mobilitas_perjadinkegiatans.id', $id)
                ->first();
    $infoKegiatan = $infoKegiatan->data_perjadinkegiatan;
    $info = DB::table('mobilitas_perjadinkegiatans')
        ->join('data_perjadinkegiatans', 'mobilitas_perjadinkegiatans.data_perjadinkegiatan', '=', 'data_perjadinkegiatans.id')
        ->select(
            'mobilitas_perjadinkegiatans.data_perjadinkegiatan',
            'mobilitas_perjadinkegiatans.tujuan_penggunaan',
            'data_perjadinkegiatans.nama_kegiatan',
            'data_perjadinkegiatans.tgl_mulai',
            'data_perjadinkegiatans.tgl_selesai',
            'data_perjadinkegiatans.alamat',
            'data_perjadinkegiatans.provinsi',
            'data_perjadinkegiatans.is_acceptBMN',
            'data_perjadinkegiatans.kab_kota',
            'data_perjadinkegiatans.jumlah_kamar',
            'data_perjadinkegiatans.jumlah_peserta',
            'data_perjadinkegiatans.tambah_penginapan'
        )
        ->where('mobilitas_perjadinkegiatans.id', $id)
        ->first();

    // Parse dates for use in data fetching
    $tanggalMulai = Carbon::parse($info->tgl_mulai);
    $tanggalSelesai = Carbon::parse($info->tgl_selesai);

    $pesertaPegawais = DB::table('perangkat_acaras')
    ->join('pegawais', 'perangkat_acaras.pegawai_id', '=', 'pegawais.id')
    ->select(
        'pegawais.nama_lengkap',
        'pegawais.pangkat',
        'pegawais.golongan',
        'perangkat_acaras.posisi as sebagai',
        'perangkat_acaras.status as status_pegawai' // Ambil status dari perangkat_acaras
    )
    ->where('perangkat_acaras.data_perjadin_kegiatan', $infoKegiatan)
    ->get();

// Fetch Non-Pegawai Participants
$pesertaNonPegawais = DB::table('perangkat_acaras')
    ->join('non_pegawais', 'perangkat_acaras.non_pegawai_id', '=', 'non_pegawais.id')
    ->select(
        'non_pegawais.nama_lengkap',
        'non_pegawais.pangkat',
        'non_pegawais.golongan',
        'perangkat_acaras.posisi as sebagai',
        'perangkat_acaras.status as status_pegawai' // Ambil status dari perangkat_acaras
    )
    ->where('perangkat_acaras.data_perjadin_kegiatan', $infoKegiatan)
    ->get();

$mobilitass = DB::table('peminjaman_kendaraan_dinas')
    ->leftJoin('pegawais','peminjaman_kendaraan_dinas.pegawai_id','=','pegawais.id')
    ->leftJoin('kendaraans','peminjaman_kendaraan_dinas.kendaraan','=','kendaraans.id')
    ->leftJoin('mobilitas_perjadinkegiatans','peminjaman_kendaraan_dinas.mobilitas_perjadinkegiatan','=','mobilitas_perjadinkegiatans.id')
    ->leftJoin('data_perjadinkegiatans','mobilitas_perjadinkegiatans.data_perjadinkegiatan','=','data_perjadinkegiatans.id')
    ->select('peminjaman_kendaraan_dinas.id AS id_peminjaman','data_perjadinkegiatans.*','peminjaman_kendaraan_dinas.*','pegawais.id AS id_pegawai','pegawais.nama_lengkap','kendaraans.merek','kendaraans.no_polisi')
    ->where('peminjaman_kendaraan_dinas.mobilitas_perjadinkegiatan',$id)
    ->get();

    return view('admin.kegiatan.mobilitas.detail', [
        'title' => 'Detail Mobilitas Kegiatan',
        'infoKegiatan' => $info,
        'kegiatan' => $infoKegiatan,
        'mobilitass' => $mobilitass,
        'pesertaNonPegawais' => $pesertaNonPegawais,
        'mobilitasID' => $id,
        'pesertaPegawais' => $pesertaPegawais,
        'dokumens' => Laporan_perjadinkegiatan::where('data_perjadin_kegiatan', $infoKegiatan)->get()
    ]);
}

public function cekMobilitasAPI(Request $request)
{
    // Parsing tanggal dari request menggunakan Carbon
    $tanggalAwal = Carbon::parse($request->input('tanggal_awal'));
    $tanggalAkhir = Carbon::parse($request->input('tanggal_akhir'));
    $kegiatanID = $request->input('kegiatanID');

    // Query untuk mendapatkan kendaraan yang tersedia
    $kendaraans = DB::table('kendaraans')
        ->select('kendaraans.*')
        ->where('kendaraans.status', '=', 'baik')
        ->where('kendaraans.tipe', '=', 'Roda Empat')
        ->whereNotExists(function ($query) use ($tanggalAwal, $tanggalAkhir) {
            $query->select(DB::raw(1))
                ->from('peminjaman_kendaraan_dinas')
                ->whereRaw('kendaraans.id = peminjaman_kendaraan_dinas.kendaraan')
                ->where(function ($subquery) use ($tanggalAwal, $tanggalAkhir) {
                    $subquery
                        ->where('peminjaman_kendaraan_dinas.tgl_keberangkatan', '<=', $tanggalAkhir)
                        ->where('peminjaman_kendaraan_dinas.tgl_selesai', '>=', $tanggalAwal)
                        ->where('peminjaman_kendaraan_dinas.status', '!=', 'ditolak');
                });
        })
        ->distinct()
        ->get();

    // Query untuk mendapatkan pengemudi yang tidak sedang dalam perjalanan dinas
    $pengemudis = DB::table('pegawais')
        ->join('jabatans', 'pegawais.jabatan_id', '=', 'jabatans.id')
        ->select('pegawais.id', 'pegawais.nama_lengkap', 'jabatans.nama_jabatan')
        ->where('jabatans.nama_jabatan', 'Pengemudi')
        ->whereNotExists(function ($query) use ($tanggalAwal, $tanggalAkhir) {
            $query->select(DB::raw(1))
                ->from('peminjaman_kendaraan_dinas')
                ->whereRaw('pegawais.id = peminjaman_kendaraan_dinas.pegawai_id')
                ->where(function ($subquery) use ($tanggalAwal, $tanggalAkhir) {
                    $subquery
                        ->where('peminjaman_kendaraan_dinas.tgl_keberangkatan', '<=', $tanggalAkhir)
                        ->where('peminjaman_kendaraan_dinas.tgl_selesai', '>=', $tanggalAwal)
                        ->where('peminjaman_kendaraan_dinas.status', '!=', 'ditolak');
                });
        })
        ->distinct()
        ->get();

    $pegawaiPengemudis = [];
    // Jalankan query untuk pegawai pengemudi hanya jika perjadinID ada
    if (!empty($kegiatanID)) {
        $pegawaiPengemudis = DB::table('pegawais')
            ->join('perangkat_acaras', 'pegawais.id', '=', 'perangkat_acaras.pegawai_id')
            ->select('pegawais.id', 'pegawais.nama_lengkap', 'jabatans.nama_jabatan')
            ->join('jabatans', 'pegawais.jabatan_id', '=', 'jabatans.id')
            ->where('perangkat_acaras.data_perjadin_kegiatan', $kegiatanID)
            // ->whereNotExists(function ($query) use ($tanggalAwal, $tanggalAkhir) {
            //     $query->select(DB::raw(1))
            //         ->from('peminjaman_kendaraan_dinas')
            //         ->whereRaw('pegawais.id = peminjaman_kendaraan_dinas.pegawai_id')
            //         ->where(function ($subquery) use ($tanggalAwal, $tanggalAkhir) {
            //             $subquery
            //                 ->where('peminjaman_kendaraan_dinas.tgl_keberangkatan', '<=', $tanggalAkhir)
            //                 ->where('peminjaman_kendaraan_dinas.tgl_selesai', '>=', $tanggalAwal)
            //                 ->where('peminjaman_kendaraan_dinas.status', '!=', 'ditolak');
            //         });
            // })
            ->distinct()
            ->get();
    }

    // Return data dalam format JSON
    return response()->json([
        'kendaraans' => $kendaraans,
        'pengemudis' => $pengemudis,
        'pegawaiPengemudis' => $pegawaiPengemudis, // Sertakan pegawaiPengemudi dalam respons
    ]);
}


    public function detail_sapras(Request $request, $id)
    {
        $info = DB::table('peminjaman_sarpras')
                        ->join('data_perjadinkegiatans', 'peminjaman_sarpras.data_perjadinkegiatan', '=', 'data_perjadinkegiatans.id')
                        ->select('data_perjadinkegiatans.nama_kegiatan','data_perjadinkegiatans.tgl_mulai', 'data_perjadinkegiatans.alamat', 'peminjaman_sarpras.data_perjadinkegiatan')
                        ->where('data_perjadinkegiatans.id', $id)
                        ->get();
        $peminjaman = DB::table('peminjaman_sarpras')
                        ->join('pegawais', 'peminjaman_sarpras.pegawai_id', '=', 'pegawais.id')
                        ->join('assets', 'peminjaman_sarpras.asset', '=', 'assets.id')
                        ->join('data_perjadinkegiatans', 'peminjaman_sarpras.data_perjadinkegiatan', '=', 'data_perjadinkegiatans.id')
                        ->select('peminjaman_sarpras.id as idPeminjaman', 'pegawais.nama_lengkap','assets.id as idBarang', 'assets.nama_barang', 'peminjaman_sarpras.jumlah_asset', 'peminjaman_sarpras.keterangan', 'peminjaman_sarpras.status', 'data_perjadinkegiatans.id')
                        ->where('data_perjadinkegiatans.id', $id)
                        ->where('peminjaman_sarpras.versi_id', session('versi'))
                        ->get();
        return view('admin.kegiatan.assets.detail', [
            'title' => 'Detail Sapras Kegiatan',
            'info' => $info,
            'peminjamans' => $peminjaman,
        ]);
    }

    public function detail_keuangan(Request $request, $id)
    {
        $pegawais = DB::table('perangkat_acaras')
                        ->join('fasilitas', 'perangkat_acaras.fasilitas_id', '=', 'fasilitas.id')
                        ->join('pegawais', 'perangkat_acaras.pegawai_id', '=', 'pegawais.id')
                        ->join('keuangan_perjadinkegiatans', 'keuangan_perjadinkegiatans.perangkat_acara', '=', 'perangkat_acaras.id')
                        ->select('pegawais.id as idPegawai', 'pegawais.nama_lengkap','pegawais.pangkat', 'pegawais.golongan', 'perangkat_acaras.posisi', 'perangkat_acaras.detail_satuan', 'perangkat_acaras.satuan', 'perangkat_acaras.sebagai','perangkat_acaras.status', 'perangkat_acaras.fasilitas_id', 'fasilitas.nama_fasilitas', 'perangkat_acaras.id as idPerangkatAcara', 'keuangan_perjadinkegiatans.id as idKeuangan', 'keuangan_perjadinkegiatans.data_perjadinkegiatan as idKegiatan')
                        ->where('keuangan_perjadinkegiatans.data_perjadinkegiatan', $id)
                        ->get();
        $nonpegawais = DB::table('perangkat_acaras')
                        ->join('fasilitas', 'perangkat_acaras.fasilitas_id', '=', 'fasilitas.id')
                        ->join('non_pegawais', 'perangkat_acaras.non_pegawai_id', '=', 'non_pegawais.id')
                        ->join('keuangan_perjadinkegiatans', 'keuangan_perjadinkegiatans.perangkat_acara', '=', 'perangkat_acaras.id')
                        ->select('non_pegawais.id as idNonPegawai', 'non_pegawais.nama_lengkap','non_pegawais.pangkat', 'non_pegawais.golongan','perangkat_acaras.posisi', 'perangkat_acaras.detail_satuan','perangkat_acaras.sebagai', 'perangkat_acaras.satuan', 'perangkat_acaras.status', 'fasilitas.nama_fasilitas', 'perangkat_acaras.fasilitas_id', 'perangkat_acaras.id as idPerangkatAcara', 'keuangan_perjadinkegiatans.id as idKeuangan', 'keuangan_perjadinkegiatans.data_perjadinkegiatan as idKegiatan')
                        ->where('keuangan_perjadinkegiatans.data_perjadinkegiatan', $id)
                        ->get();
        $operasionals = DB::table('keuangan_perjadinkegiatans')
                        ->join('operasionals', 'keuangan_perjadinkegiatans.operasional', '=', 'operasionals.id')
                        ->select('operasionals.id', 'operasionals.status', 'operasionals.nama', 'operasionals.jumlah_frekuensi', 'operasionals.satuan', 'operasionals.detail_satuan', 'keuangan_perjadinkegiatans.operasional', 'keuangan_perjadinkegiatans.data_perjadinkegiatan')
                        ->where('keuangan_perjadinkegiatans.data_perjadinkegiatan', $id)
                        ->get();
        $keuanganOperasional = DB::table('keuangan_perjadinkegiatans')
                        ->join('operasionals', 'keuangan_perjadinkegiatans.operasional', '=', 'operasionals.id')
                        ->select('keuangan_perjadinkegiatans.akun_x_rkakl', 'keuangan_perjadinkegiatans.harga', 'keuangan_perjadinkegiatans.persen_pajak', 'keuangan_perjadinkegiatans.jumlah_harga', 'keuangan_perjadinkegiatans.data_perjadinkegiatan', 'keuangan_perjadinkegiatans.operasional', 'operasionals.nama', 'operasionals.jumlah_frekuensi')
                        ->where('keuangan_perjadinkegiatans.data_perjadinkegiatan', $id)
                        ->get();
        return view('admin.kegiatan.keuangan.detail', [
            'title' => 'Detail Keuangan',
            'info' => Data_perjadinkegiatan::find($id),
            'dokumens' => Laporan_perjadinkegiatan::where('data_perjadin_kegiatan', $id)->get(),
            "perangkats" => Fasilitas::where('data_perjadinkegiatan_id', $id)->get(),
            'pegawais' => $pegawais,
            'nonpegawais' => $nonpegawais,
            "operasionals" => $operasionals,
            "keuanganoperasionals" => $keuanganOperasional,
        ]);
    }

    public function detail_bendahara(Request $request, $id)
    {
        $pegawais = DB::table('perangkat_acaras')
                        ->join('fasilitas', 'perangkat_acaras.fasilitas_id', '=', 'fasilitas.id')
                        ->join('pegawais', 'perangkat_acaras.pegawai_id', '=', 'pegawais.id')
                        ->join('keuangan_perjadinkegiatans', 'keuangan_perjadinkegiatans.perangkat_acara', '=', 'perangkat_acaras.id')
                        ->select('pegawais.id as idPegawai', 'pegawais.nama_lengkap','pegawais.pangkat', 'pegawais.golongan', 'perangkat_acaras.posisi', 'perangkat_acaras.detail_satuan', 'perangkat_acaras.satuan','perangkat_acaras.sebagai', 'perangkat_acaras.status', 'perangkat_acaras.fasilitas_id', 'fasilitas.nama_fasilitas', 'perangkat_acaras.id as idPerangkatAcara', 'keuangan_perjadinkegiatans.id as idKeuangan', 'keuangan_perjadinkegiatans.data_perjadinkegiatan as idKegiatan', 'keuangan_perjadinkegiatans.pph22', 'keuangan_perjadinkegiatans.pph23', 'keuangan_perjadinkegiatans.ppn', 'keuangan_perjadinkegiatans.tgl_bayar')
                        ->where('keuangan_perjadinkegiatans.data_perjadinkegiatan', $id)
                        ->get();
        $nonpegawais = DB::table('perangkat_acaras')
                        ->join('fasilitas', 'perangkat_acaras.fasilitas_id', '=', 'fasilitas.id')
                        ->join('non_pegawais', 'perangkat_acaras.non_pegawai_id', '=', 'non_pegawais.id')
                        ->join('keuangan_perjadinkegiatans', 'keuangan_perjadinkegiatans.perangkat_acara', '=', 'perangkat_acaras.id')
                        ->select('non_pegawais.id as idNonPegawai', 'non_pegawais.nama_lengkap','non_pegawais.pangkat', 'non_pegawais.golongan','perangkat_acaras.posisi', 'perangkat_acaras.detail_satuan', 'perangkat_acaras.satuan','perangkat_acaras.sebagai', 'perangkat_acaras.status', 'fasilitas.nama_fasilitas', 'perangkat_acaras.fasilitas_id', 'perangkat_acaras.id as idPerangkatAcara', 'keuangan_perjadinkegiatans.id as idKeuangan', 'keuangan_perjadinkegiatans.data_perjadinkegiatan as idKegiatan', 'keuangan_perjadinkegiatans.pph22', 'keuangan_perjadinkegiatans.pph23', 'keuangan_perjadinkegiatans.ppn', 'keuangan_perjadinkegiatans.tgl_bayar')
                        ->where('keuangan_perjadinkegiatans.data_perjadinkegiatan', $id)
                        ->get();
        $operasionals = DB::table('keuangan_perjadinkegiatans')
                        ->join('operasionals', 'keuangan_perjadinkegiatans.operasional', '=', 'operasionals.id')
                        ->select('operasionals.id', 'operasionals.status', 'operasionals.nama', 'operasionals.jumlah_frekuensi', 'operasionals.satuan', 'operasionals.detail_satuan', 'keuangan_perjadinkegiatans.operasional', 'keuangan_perjadinkegiatans.data_perjadinkegiatan', 'keuangan_perjadinkegiatans.pph22', 'keuangan_perjadinkegiatans.pph23', 'keuangan_perjadinkegiatans.ppn', 'keuangan_perjadinkegiatans.tgl_bayar')
                        ->where('keuangan_perjadinkegiatans.data_perjadinkegiatan', $id)
                        ->get();
        $keuanganOperasional = DB::table('keuangan_perjadinkegiatans')
                        ->join('operasionals', 'keuangan_perjadinkegiatans.operasional', '=', 'operasionals.id')
                        ->select('keuangan_perjadinkegiatans.akun_x_rkakl', 'keuangan_perjadinkegiatans.harga', 'keuangan_perjadinkegiatans.persen_pajak', 'keuangan_perjadinkegiatans.jumlah_harga', 'keuangan_perjadinkegiatans.data_perjadinkegiatan', 'keuangan_perjadinkegiatans.operasional', 'keuangan_perjadinkegiatans.status', 'operasionals.nama', 'operasionals.jumlah_frekuensi', 'keuangan_perjadinkegiatans.pph22', 'keuangan_perjadinkegiatans.pph23', 'keuangan_perjadinkegiatans.ppn', 'keuangan_perjadinkegiatans.tgl_bayar')
                        ->where('keuangan_perjadinkegiatans.data_perjadinkegiatan', $id)
                        ->get();
        $akuns = DB::table('akun_x_rkakls')
                        ->join('akuns', 'akun_x_rkakls.akun_id', '=', 'akuns.id')
                        ->join('ref_rkakl_sub_komponens', 'akun_x_rkakls.ref_sub_komponen_id', '=', 'ref_rkakl_sub_komponens.id')
                        ->join('ref_rkakl_komponens', 'ref_rkakl_sub_komponens.ref_rkakl_komponen_id', '=', 'ref_rkakl_komponens.id')
                        ->join('ref_rkakl_suboutputs', 'ref_rkakl_komponens.ref_rkakl_suboutput_id', '=', 'ref_rkakl_suboutputs.id')
                        ->join('ref_rkakl_outputs', 'ref_rkakl_suboutputs.ref_rkakl_output_id', '=', 'ref_rkakl_outputs.id')
                        ->join('ref_rkakl_kegiatans', 'ref_rkakl_outputs.ref_rkakl_kegiatan_id', '=', 'ref_rkakl_kegiatans.id')
                        ->join('ref_rkakl_programs', 'ref_rkakl_kegiatans.ref_rkakl_program_id', '=', 'ref_rkakl_programs.id')
                        ->join('ref_rkakl_satkers', 'ref_rkakl_programs.ref_rkakl_satker_id', '=', 'ref_rkakl_satkers.id')
                        ->select('akun_x_rkakls.id as idAkun', 'ref_rkakl_sub_komponens.nama_sub_kegiatan', 'akuns.uraian', 'ref_rkakl_satkers.kode_satker', 'ref_rkakl_programs.kode_program', 'ref_rkakl_kegiatans.kode_kegiatan', 'ref_rkakl_outputs.kode_output', 'ref_rkakl_suboutputs.kode_sub_output', 'ref_rkakl_komponens.kode_komponen', 'ref_rkakl_sub_komponens.kode_sub_kegiatan', 'ref_rkakl_sub_komponens.nama_sub_kegiatan', 'akuns.kode_akun', 'akuns.uraian')
                        ->get();
        return view('admin.kegiatan.bendahara.detail', [
            'title' => 'Detail Keuangan',
            'info' => Data_perjadinkegiatan::find($id),
            "perangkats" => Fasilitas::where('data_perjadinkegiatan_id', $id)->get(),
            'pegawais' => $pegawais,
            'nonpegawais' => $nonpegawais,
            "operasionals" => $operasionals,
            "keuanganoperasionals" => $keuanganOperasional,
            'keuangans' => Keuangan_perjadinkegiatan::where('data_perjadinkegiatan', $id)->get(),
            "sbms" => Ref_sbm::all(),
            'akuns' => $akuns
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $action = $request->input('action');

        $pengusul = DB::table('pegawais')
            ->join('data_perjadinkegiatans', 'pegawais.id', '=', 'data_perjadinkegiatans.id_pengaju')
            ->select('data_perjadinkegiatans.id_pengaju', 'pegawais.nama_lengkap')
            ->where('data_perjadinkegiatans.id',$request->input('idKegiatan'))
            ->first(); // Mengambil hasil pertama


        $dokumen = DB::table('laporan_perjadinkegiatans')
            ->where('laporan_perjadinkegiatans.data_perjadin_kegiatan',$request->input('idKegiatan'))
            ->first();



        if ($action === 'proses') {
            $numMobilitas = $request->input('numMobilitas');

            for ($i = 0; $i < $numMobilitas; $i++) {
                $idMobilitas = $request->input('idMobilitas_' . $i);
                $kendaraan = $request->input('mobil_' . $i);
                $namaKegiatan = $request->input('nama_kegiatan_' . $i);
                $provinsi = $request->input('provinsi_' . $i);
                $alamat = $request->input('alamat_' . $i);
                $kabKota = $request->input('kabupaten_kota_' . $i);
                $supir = $request->input('supir_' . $i);
                $status = $request->input('status_' . $i);
                $berangkat = $request->input('tglBerangkat_' . $i);
                $selesai = $request->input('tglSelesai_' . $i);
                $ketMobilitas = $request->input('ket_' . $i);
                $gabungSurtug = $request->input('gabungSurtug_' . $i);

                // Konversi format tanggal
                $berangkat = Carbon::createFromFormat('d-m-Y H:i', $berangkat)->format('Y-m-d H:i:s');
                $selesai = Carbon::createFromFormat('d-m-Y H:i', $selesai)->format('Y-m-d H:i:s');

                // Update kendaraan
                DB::table('kendaraans')
                    ->join('peminjaman_kendaraan_dinas', 'peminjaman_kendaraan_dinas.kendaraan', '=', 'kendaraans.id')
                    ->where('kendaraans.id', $kendaraan)
                    ->update([
                        'kendaraans.updated_at' => now()->format('Y-m-d H:i:s'),
                    ]);

                if(!$gabungSurtug){
                    if($ketMobilitas == "Antar"){
                        $namaKegiatan = "Mengantar Pelaksana Tugas ".$namaKegiatan;
                    } elseif ($ketMobilitas == "Jemput") {
                        $namaKegiatan = "Menjemput Pelaksana Tugas ".$namaKegiatan;
                    } elseif ($ketMobilitas == "Antar-Jemput") {
                        $namaKegiatan = "Mengantar dan Menjemput Pelaksana Tugas ".$namaKegiatan;
                    }


                    $versi = Versi::where('status', 'aktif')->get();
                    DB::table('data_perjadinkegiatans')->insertOrIgnore([
                        'nama_kegiatan' => $namaKegiatan,
                        'tgl_mulai' => $berangkat,
                        'tgl_selesai' => $selesai,
                        'is_acceptAset' => '-',
                        'provinsi' => $provinsi,
                        'kab_kota' => $kabKota,
                        'jumlah_peserta' => 0,
                        'jumlah_kepanitiaan' => 0,
                        'jumlah_kamar' => 0,
                        'tambah_penginapan' => 0,
                        'alamat' => $alamat,
                        'status' => 'proses',
                        'status_pengajuan' => 'Draf-pengajuan',
                        'versi_id' => $versi[0]->id,
                        'created_at' => now()->format('Y-m-d H:i:s'),
                        'updated_at' => now()->format('Y-m-d H:i:s'),
                    ]);

                    $kegiatanBaru = Data_perjadinkegiatan::max('id');

                    DB::table('laporan_perjadinkegiatans')->insertOrIgnore([
                        'nama_dokumen' => $dokumen->nama_dokumen,
                        'file' => $dokumen->file,
                        'status' => $dokumen->status,
                        'data_perjadin_kegiatan' => $kegiatanBaru,
                        'keterangan' => 'Bukan Dokumen Induk',
                        // 'versi_id' => $versi[0]->id,
                        'created_at' => now()->format('Y-m-d H:i:s'),
                        'updated_at' => now()->format('Y-m-d H:i:s'),
                    ]);

                    DB::table('mobilitas_perjadinkegiatans')->insertOrIgnore([
                        'mobilitas' => 'Kendaraan Dinas LLDIKTI',
                        'tujuan_penggunaan' => $ketMobilitas,
                        'tgl_mulai' => $berangkat,
                        'tgl_selesai' => $selesai,
                        'status' => 'selesai',
                        'unit' => 1,
                        'data_perjadinkegiatan' => $kegiatanBaru,
                        'versi_id' => $versi[0]->id,
                        'created_at' => now()->format('Y-m-d H:i:s'),
                        'updated_at' => now()->format('Y-m-d H:i:s'),
                    ]);

                    $mobilitasBaru = Mobilitas_perjadinkegiatan::max('id');

                    // Update peminjaman kendaraan dinas
                    DB::table('peminjaman_kendaraan_dinas')
                    ->where('id', $idMobilitas)
                    ->update([
                        'mobilitas_perjadinkegiatan' => $mobilitasBaru,
                        'updated_at' => now()->format('Y-m-d H:i:s')
                    ]);


                } else {
                    // Update peminjaman kendaraan dinas
                    DB::table('peminjaman_kendaraan_dinas')
                    ->where('id', $idMobilitas)
                    ->update([
                        'pegawai_id' => $supir,
                        'status' => $status,
                        'tgl_keberangkatan' => $berangkat,
                        'tgl_selesai' => $selesai,
                        'ket_mobilitas' => $ketMobilitas,
                        'updated_at' => now()->format('Y-m-d H:i:s'),
                    ]);
                }

                $berangkat = $request->input('berangkat_' . $i);
                $selesai = $request->input('selesai_' . $i);
                $berangkat = Carbon::createFromFormat('d-m-Y H:i', $berangkat)->format('Y-m-d H:i:s');
                $selesai = Carbon::createFromFormat('d-m-Y H:i', $selesai)->format('Y-m-d H:i:s');

                // Jika status adalah 'proses'
                if ($status === 'proses') {
                    if ($gabungSurtug) {
                        $fasilitasExists = DB::table('fasilitas')
                            ->where('data_perjadinkegiatan_id',  $request->input('idKegiatan'))
                            ->where('nama_fasilitas', 'Supir')
                            ->exists();

                        if (!$fasilitasExists) {
                            DB::table('fasilitas')->insert([
                                'data_perjadinkegiatan_id' => $request->input('idKegiatan'),
                                'nama_fasilitas' => 'Supir',
                                'created_at' => now()->format('Y-m-d H:i:s'),
                                'updated_at' => now()->format('Y-m-d H:i:s'),
                            ]);

                        }
                        $fasilitas_max = Fasilitas::max('id');

                        DB::table('perangkat_acaras')->insertOrIgnore([
                            'sebagai' => 'Supir',
                            'posisi' => 'Supir',
                            'data_perjadin_kegiatan' => $request->input('idKegiatan'),
                            'pegawai_id' => $supir,
                            'fasilitas_id' => $fasilitas_max,
                            // 'tgl_keberangkatan' => $berangkat,
                            // 'tgl_selesai' => $selesai,
                            'status' => 'Diproses',
                            'created_at' => now()->format('Y-m-d H:i:s'),
                            'updated_at' => now()->format('Y-m-d H:i:s'),
                        ]);

                        $perangkat_acaras_max = Perangkat_acara::max('id');

                        $mobilitasLama = DB::table('mobilitas_perjadinkegiatans')
                            ->where('data_perjadinkegiatan', $request->input('idKegiatan'))
                            ->first();

                        DB::table('operasionals')->insertOrIgnore([
                            'nama' => $ketMobilitas,
                            'jumlah_frekuensi' => '1',
                            'ket' => 'Keperluan Operasional',
                            'status' => 'pengajuan',
                            'data_perjadin_kegiatan' => $mobilitasLama->id,
                            'created_at' => now()->format('Y-m-d H:i:s'),
                            'updated_at' => now()->format('Y-m-d H:i:s'),
                        ]);

                        $operasionals_max = Operasional::max('id');

                        DB::table('keuangan_perjadinkegiatans')->insertOrIgnore([
                            'data_perjadinkegiatan' => $request->input('idKegiatan'),
                            'perangkat_acara' => $perangkat_acaras_max,
                            'operasional' => $operasionals_max,
                            'status' => 'Menunggu Persetujuan Bendahara',
                            'created_at' => now()->format('Y-m-d H:i:s'),
                            'updated_at' => now()->format('Y-m-d H:i:s'),
                        ]);



                    } else {
                        DB::table('fasilitas')->insert([
                            'data_perjadinkegiatan_id' => $kegiatanBaru,
                            'nama_fasilitas' => 'Supir',
                            'created_at' => now()->format('Y-m-d H:i:s'),
                            'updated_at' => now()->format('Y-m-d H:i:s'),
                        ]);

                        $fasilitas_new_max = Fasilitas::max('id');

                        DB::table('perangkat_acaras')->insertOrIgnore([
                            'sebagai' => 'Supir',
                            'posisi' => 'Supir',
                            'data_perjadin_kegiatan' => $kegiatanBaru,
                            'pegawai_id' => $supir,
                            'fasilitas_id' => $fasilitas_new_max,
                            // 'tgl_keberangkatan' => $berangkat,
                            // 'tgl_selesai' => $selesai,
                            'status' => 'Diproses',
                            'created_at' => now()->format('Y-m-d H:i:s'),
                            'updated_at' => now()->format('Y-m-d H:i:s'),
                        ]);

                        $perangkat_acaras_new_max = Perangkat_acara::max('id');

                        DB::table('operasionals')->insertOrIgnore([
                            'nama' => $ketMobilitas,
                            'jumlah_frekuensi' => '1',
                            'ket' => 'Keperluan Operasional',
                            'status' => 'pengajuan',
                            'data_perjadin_kegiatan' => $mobilitasBaru,
                            'created_at' => now()->format('Y-m-d H:i:s'),
                            'updated_at' => now()->format('Y-m-d H:i:s'),
                        ]);

                        $operasionals_new_max = Operasional::max('id');

                        DB::table('keuangan_perjadinkegiatans')->insertOrIgnore([
                            'data_perjadinkegiatan' => $kegiatanBaru,
                            'perangkat_acara' => $perangkat_acaras_new_max,
                            'operasional' => $operasionals_new_max,
                            'status' => 'Menunggu Persetujuan Bendahara',
                            'created_at' => now()->format('Y-m-d H:i:s'),
                            'updated_at' => now()->format('Y-m-d H:i:s'),
                        ]);
                    }
                }

                if (!$gabungSurtug) {
                    DB::table('data_perjadinkegiatans')
                    ->where('id', $kegiatanBaru)
                    ->update([
                        'is_acceptBMN' => 'proses',
                        'is_acceptHKT' => 'pengajuan',
                        'status_pengajuan'  => 'proses',
                        'status' => 'pengajuan',
                        'status_pengajuan_detail' => 'Verifikasi-HKT',
                        'id_pengaju' => auth('administrator')->user()->id,
                        'admin_BMN' => auth('administrator')->user()->id,
                        'updated_at' => now()->format('Y-m-d H:i:s'),
                    ]);
                }

            }
            DB::table('data_perjadinkegiatans')
                    ->where('id', $request->input('idKegiatan'))
                    ->update([
                        'is_acceptBMN' => 'proses',
                        'is_acceptHKT' => 'pengajuan',
                        'status_pengajuan'  => 'proses',
                        'status' => 'pengajuan',
                        'status_pengajuan_detail' => 'Verifikasi-HKT',
                        'admin_BMN' => auth('administrator')->user()->id,
                        'updated_at' => now()->format('Y-m-d H:i:s'),
                    ]);

                    DB::table('mobilitas_perjadinkegiatans')
                    ->where('data_perjadinkegiatan', $request->input('idKegiatan'))
                    ->update([
                        'status' => 'selesai',
                        'updated_at' => now()->format('Y-m-d H:i:s'),
                    ]);



            $dataNotif = [
                'id_kegiatan' => $request->input('idKegiatan'),
                'from' => auth('administrator')->user()->id, // ID pengguna yang mengirim
                'to' => 0, // ID pengguna yang menerima
                'role' => 'HKT', // Peran pengguna
                'header' => 'Usulan Kegiatan - '.$request->input('idKegiatan'), // Judul notifikasi
                'message' => 'Usulan '.$request->input('idKegiatan').' telah diverifikasi BMN', // Isi pesan
                'route' => 'kegiatan-HKT/detail/'.$request->input('idKegiatan'), // Route yang dituju
                'is_read' => 0, // Status belum dibaca
                'created_at' => now()->format('Y-m-d H:i:s'), // Waktu saat dibuat
            ];

            // Melakukan insert ke tabel notifications
            DB::table('notifications')->insert($dataNotif);

            $dataNotifUser = [
                    'id_kegiatan' => $request->input('idKegiatan'),
                    'from' => auth('administrator')->user()->id, // ID pengguna yang mengirim
                    'to' => '0', // ID pengguna yang menerima
                    'role' => null, // Peran pengguna
                    'header' => 'Usulan Kegiatan Disetujui BMN - '.$request->input('idKegiatan'), // Judul notifikasi
                    'message' => 'Usulan yang diajukan dengan id '.$request->input('idKegiatan').' telah diproses BMN harap menunggu Verifikasi-HKT', // Isi pesan
                    'route' => 'kegiatan/riwayat/proses', // Route yang dituju
                    'is_read' => 0, // Status belum dibaca
                    'created_at' => now()->format('Y-m-d H:i:s'), // Waktu saat dibuat
                    ];

                // Melakukan insert ke tabel notifications
                DB::table('notifications')->insert($dataNotifUser);


            return redirect()->route('mobilitas', ['status' => $request->input('kegiatanStatus')])->with('success', 'Data telah diperbaharui!');
        } elseif ($action === 'tolak') {
            DB::table('data_perjadinkegiatans')
                ->where('id', $request->input('idKegiatan'))
                ->update([
                    'status_pengajuan_detail' => 'Verifikasi-BMN-ditolak',
                    'status_pengajuan' => 'ditolak',
                    'is_acceptBMN' => 'ditolak',
                    'alasan_penolakan' =>  $request->input('alasan'),
                    'admin_BMN' => auth('administrator')->user()->id,
                    'updated_at' => now()->format('Y-m-d H:i:s'),
                ]);

            DB::table('mobilitas_perjadinkegiatans')
                ->where('data_perjadinkegiatan', $request->input('idKegiatan'))
                ->update([
                    'status' => 'ditolak',
                    'updated_at' => now()->format('Y-m-d H:i:s'),
                ]);

            

                // DB::table('peminjaman_kendaraan_dinas')
                // ->where('id', $request->input('idKegiatan'))
                // ->update([
                //     'status_pengajuan_detail' => 'Verifikasi-BMN-ditolak',
                //     'status_pengajuan' => 'ditolak',
                //     'is_acceptBMN' => 'ditolak',
                //     'alasan_penolakan' =>  $request->input('alasan'),
                //     'admin_BMN' => auth('administrator')->user()->id,
                //     'updated_at' => now()->format('Y-m-d H:i:s'),
                // ]);

            DB::table('perangkat_acaras')
                ->where('data_perjadin_kegiatan', $request->input('idKegiatan'))
                ->update([
                    'status' => 'Ditolak',
                    'updated_at' => now()->format('Y-m-d H:i:s'),
                ]);

            $dataNotif = [
                'id_kegiatan' => $request->input('idKegiatan'),
                'from' => auth('administrator')->user()->id, // ID pengguna yang mengirim
                'to' => '0', // ID pengguna yang menerima
                'role' => null, // Peran pengguna
                'header' => 'Usulan Kegiatan Ditolak - '.$request->input('idKegiatan'), // Judul notifikasi
                'message' => 'Usulan yang diajukan dengan id '.$request->input('idKegiatan').' ditolak oleh BMN', // Isi pesan
                'route' => 'kegiatan/riwayat/ditolak', // Route yang dituju
                'is_read' => 0, // Status belum dibaca
                'created_at' => now()->format('Y-m-d H:i:s'), // Waktu saat dibuat
                ];

            // Melakukan insert ke tabel notifications
            DB::table('notifications')->insert($dataNotif);

            return redirect()->route('mobilitas', ['status' => $request->input('kegiatanStatus')])->with('success', 'Pengajuan Telah Ditolak!');
        }
    }

    
    public function storeMobilitas(Request $request)
    {
        // $gabungSurtug = $request->gabungSurtug;
        // Pengecekan apakah semua data ada
        $requiredFields = [
            'kendaraan',
            'pengemudi',
            'ket_mobilitas',
            'tgl_keberangkatan'
        ];

        foreach ($requiredFields as $field) {
            if (is_null($request->input($field))) {
                return redirect()->route('detail-mobilitas-kegiatan', ['id' => $request->idMobilitas])
                                ->with('success', 'Data tidak berhasil ditambahkan, data tidak lengkap');
            }
        }

        db::table('peminjaman_kendaraan_dinas')->insertOrIgnore([
            'mobilitas_perjadinkegiatan' => $request->idMobilitas,
            'kendaraan' => $request->kendaraan,
            'pegawai_id' => $request->pengemudi,
            'ket_mobilitas' => $request->ket_mobilitas,
            'tgl_keberangkatan' => $request->tgl_keberangkatan,
            'tgl_selesai' => $request->tgl_keberangkatan,
            'status' => "pengajuan",
            'created_at' => now()->format('Y-m-d H:i:s'),
            'updated_at' => now()->format('Y-m-d H:i:s'),
        ]);

        DB::table('data_perjadinkegiatans')
            ->where('id', $request->idKegiatan)
            ->update([
                'is_acceptBMN' => 'pengajuan',
                'admin_BMN' => auth('administrator')->user()->id,
                'updated_at' => now()->format('Y-m-d H:i:s'),
            ]);

        return redirect()->route('detail-mobilitas-kegiatan', ['id' => $request->idMobilitas])->with('success', 'Data telah ditambahkan, silahkan isi supir dan kendaraannya!');
    }

    public function storeKeuangan(Request $request) {

        $action = $request->input('action');

        if ($action === 'verifikasi') {
            
            $totaldokumen = $request->numDokumen;
            for ($i=0; $i < $totaldokumen; $i++) { 
                $idDokumen = 'idDokumen_' . $i;
                $statusDokumen = 'statusDokumen_' . $i;
                $keteranganDokumen = 'keteranganDokumen_' . $i;
                DB::table('laporan_perjadinkegiatans')
                ->where('id', $request->$idDokumen)
                ->update([
                    'status' => $request->$statusDokumen,
                    'keterangan' => $request->$keteranganDokumen,
                    'updated_at' => now()->format('Y-m-d H:i:s'),
                ]);
            }

            $totalpegawai = $request->numPegawai;
            for ($i=0; $i < $totalpegawai; $i++) { 
                $idPegawai = 'idPegawai_' . $i;
                $statusPegawai = 'statusPegawai_' . $i;
                DB::table('perangkat_acaras')
                ->where('pegawai_id', $request->$idPegawai)
                ->update([
                    'status' => $request->$statusPegawai,
                    'updated_at' => now()->format('Y-m-d H:i:s'),
                ]);
            }

            $totalnonpegawai = $request->numNonPegawai;
            for ($i=0; $i < $totalnonpegawai; $i++) { 
                $idnonPegawai = 'idNonPegawai_' . $i;
                $statusnonPegawai = 'statusNonPegawai_' . $i;
                DB::table('perangkat_acaras')
                ->where('non_pegawai_id', $request->$idnonPegawai)
                ->update([
                    'status' => $request->$statusnonPegawai,
                    'updated_at' => now()->format('Y-m-d H:i:s'),
                ]);
            }

            $totaloperasional = $request->numOperasional;
            for ($i=0; $i < $totaloperasional; $i++) { 
                $idOperasional = 'idOperasional_' . $i;
                $akun = 'akun_' . $i;
                $harga = 'nominal_' . $i;
                $pajak = 'pajak_' . $i;
                $total = 'total_' . $i;
                $statusOperasonal = 'kesesuaian_' . $i;
                DB::table('keuangan_perjadinkegiatans')
                ->where('operasional', $request->$idOperasional)
                ->update([
                    'harga' => $request->$harga,
                    'persen_pajak' => $request->$pajak,
                    'jumlah_harga' => $request->$total,
                    'akun_x_rkakl' => $request->$akun,
                    'updated_at' => now()->format('Y-m-d H:i:s'),
                ]);
                DB::table('operasionals')
                ->where('id', $request->$idOperasional)
                ->update([
                    'status' => $request->$statusOperasonal,
                    'updated_at' => now()->format('Y-m-d H:i:s'),
                ]);
            }

            DB::table('data_perjadinkegiatans')
                ->where('id', $request->idKegiatan)
                ->update([
                    'status' => 'pengajuan',
                    'is_acceptKeu' => 'verifikasi-2',
                    'is_acceptBend' => 'approval-1',
                    'admin_Keu' => auth('administrator')->user()->id,
                    'updated_at' => now()->format('Y-m-d H:i:s'),
                ]);

            return redirect()->route('keuangan-kegiatan', ['status' => 'verifikasi-2'])->with('success', 'Data telah diperbaharui!');

        } elseif($action === 'tolak') {
            DB::table('data_perjadinkegiatans')
                ->where('id', $request->idKegiatan)
                ->update([
                    'status' => 'ditolak',
                    'is_acceptKeu' => 'ditolak',
                    'admin_Keu' => auth('administrator')->user()->id,
                    'updated_at' => now()->format('Y-m-d H:i:s'),
                ]);
            
            return redirect()->route('keuangan-kegiatan', ['status' => 'ditolak'])->with('success', 'Program Kegiatan telah anda tolak!');
        } elseif($action === 'revisi') {
            $totaldokumen = $request->numDokumen;
            for ($i=0; $i < $totaldokumen; $i++) { 
                $idDokumen = 'idDokumen_' . $i;
                $statusDokumen = 'statusDokumen_' . $i;
                $keteranganDokumen = 'keteranganDokumen_' . $i;
                DB::table('laporan_perjadinkegiatans')
                ->where('id', $request->$idDokumen)
                ->update([
                    'status' => $request->$statusDokumen,
                    'keterangan' => $request->$keteranganDokumen,
                    'updated_at' => now()->format('Y-m-d H:i:s'),
                ]);
            }

            $totalpegawai = $request->numPegawai;
            for ($i=0; $i < $totalpegawai; $i++) { 
                $idPegawai = 'idPegawai_' . $i;
                $statusPegawai = 'statusPegawai_' . $i;
                DB::table('perangkat_acaras')
                ->where('pegawai_id', $request->$idPegawai)
                ->update([
                    'status' => $request->$statusPegawai,
                    'updated_at' => now()->format('Y-m-d H:i:s'),
                ]);
            }

            $totalnonpegawai = $request->numNonPegawai;
            for ($i=0; $i < $totalnonpegawai; $i++) { 
                $idnonPegawai = 'idNonPegawai_' . $i;
                $statusnonPegawai = 'statusNonPegawai_' . $i;
                DB::table('perangkat_acaras')
                ->where('non_pegawai_id', $request->$idnonPegawai)
                ->update([
                    'status' => $request->$statusnonPegawai,
                    'updated_at' => now()->format('Y-m-d H:i:s'),
                ]);
            }

            $totaloperasional = $request->numOperasional;
            for ($i=0; $i < $totaloperasional; $i++) { 
                $idOperasional = 'idOperasional_' . $i;
                $akun = 'akun_' . $i;
                $harga = 'nominal_' . $i;
                $pajak = 'pajak_' . $i;
                $total = 'total_' . $i;
                $statusOperasonal = 'kesesuaian_' . $i;
                DB::table('keuangan_perjadinkegiatans')
                ->where('operasional', $request->$idOperasional)
                ->update([
                    'harga' => $request->$harga,
                    'persen_pajak' => $request->$pajak,
                    'jumlah_harga' => $request->$total,
                    'akun_x_rkakl' => $request->$akun,
                    'updated_at' => now()->format('Y-m-d H:i:s'),
                ]);
                DB::table('operasionals')
                ->where('id', $request->$idOperasional)
                ->update([
                    'status' => $request->$statusOperasonal,
                    'updated_at' => now()->format('Y-m-d H:i:s'),
                ]);
            }

            if ($request->statusKegiatan == 'verifikasi-1') {
                # code...
                DB::table('data_perjadinkegiatans')
                    ->where('id', $request->idKegiatan)
                    ->update([
                        'status' => 'revisi',
                        'is_acceptKeu' => 'revisi-1',
                        'admin_Keu' => auth('administrator')->user()->id,
                        'updated_at' => now()->format('Y-m-d H:i:s'),
                    ]);
                
                return redirect()->route('keuangan-kegiatan', ['status' => 'revisi-1'])->with('success', 'Program Kegiatan telah anda tolak!');
            }
            
            if ($request->statusKegiatan == 'verifikasi-2') {
                # code...
                DB::table('data_perjadinkegiatans')
                    ->where('id', $request->idKegiatan)
                    ->update([
                        'status' => 'revisi',
                        'is_acceptKeu' => 'revisi-2',
                        'admin_Keu' => auth('administrator')->user()->id,
                        'updated_at' => now()->format('Y-m-d H:i:s'),
                    ]);
                
                return redirect()->route('keuangan-kegiatan', ['status' => 'revisi-2'])->with('success', 'Program Kegiatan telah anda tolak!');
            }

        } elseif($action === 'verifikasi-2') {
            $totaldokumen = $request->numDokumen;
            for ($i=0; $i < $totaldokumen; $i++) { 
                $idDokumen = 'idDokumen_' . $i;
                $statusDokumen = 'statusDokumen_' . $i;
                $keteranganDokumen = 'keteranganDokumen_' . $i;
                DB::table('laporan_perjadinkegiatans')
                ->where('id', $request->$idDokumen)
                ->update([
                    'status' => $request->$statusDokumen,
                    'keterangan' => $request->$keteranganDokumen,
                    'updated_at' => now()->format('Y-m-d H:i:s'),
                ]);
            }

            $totalpegawai = $request->numPegawai;
            for ($i=0; $i < $totalpegawai; $i++) { 
                $idPegawai = 'idPegawai_' . $i;
                $statusPegawai = 'statusPegawai_' . $i;
                DB::table('perangkat_acaras')
                ->where('pegawai_id', $request->$idPegawai)
                ->update([
                    'status' => $request->$statusPegawai,
                    'updated_at' => now()->format('Y-m-d H:i:s'),
                ]);
            }

            $totalnonpegawai = $request->numNonPegawai;
            for ($i=0; $i < $totalnonpegawai; $i++) { 
                $idnonPegawai = 'idNonPegawai_' . $i;
                $statusnonPegawai = 'statusNonPegawai_' . $i;
                DB::table('perangkat_acaras')
                ->where('non_pegawai_id', $request->$idnonPegawai)
                ->update([
                    'status' => $request->$statusnonPegawai,
                    'updated_at' => now()->format('Y-m-d H:i:s'),
                ]);
            }

            $totaloperasional = $request->numOperasional;
            for ($i=0; $i < $totaloperasional; $i++) { 
                $idOperasional = 'idOperasional_' . $i;
                $akun = 'akun_' . $i;
                $harga = 'nominal_' . $i;
                $pajak = 'pajak_' . $i;
                $total = 'total_' . $i;
                $statusOperasonal = 'kesesuaian_' . $i;
                DB::table('keuangan_perjadinkegiatans')
                ->where('operasional', $request->$idOperasional)
                ->update([
                    'harga' => $request->$harga,
                    'persen_pajak' => $request->$pajak,
                    'jumlah_harga' => $request->$total,
                    'akun_x_rkakl' => $request->$akun,
                    'updated_at' => now()->format('Y-m-d H:i:s'),
                ]);
                DB::table('operasionals')
                ->where('id', $request->$idOperasional)
                ->update([
                    'status' => $request->$statusOperasonal,
                    'updated_at' => now()->format('Y-m-d H:i:s'),
                ]);
            }

            DB::table('data_perjadinkegiatans')
                ->where('id', $request->idKegiatan)
                ->update([
                    'is_acceptKeu' => 'selesai',
                    'is_acceptBend' => 'approval-2',
                    'admin_Keu' => auth('administrator')->user()->id,
                    'updated_at' => now()->format('Y-m-d H:i:s'),
                ]);

            return redirect()->route('keuangan-kegiatan', ['status' => 'selesai'])->with('success', 'Data telah diperbaharui!');
        }
        

        
    }

    public function storeBendahara(Request $request) {

        $action = $request->input('action');

        if ($action === 'approve-1') {
            
            $totalpegawai = $request->numPegawai;
            for ($i=0; $i < $totalpegawai; $i++) { 
                $idPerangkatAcara = 'idPerangkatPegawai_' . $i;
                $akun = 'akunPegawai_' . $i;
                $sbm = 'sbmPegawai_' . $i;
                $nominal = 'nominalPegawai_' . $i;
                $pajak = 'pajakPegawai_' . $i;
                $pph22 = 'pajakPegawaipph22_' . $i;
                $pph23 = 'pajakPegawaipph23_' . $i;
                $ppn = 'pajakPegawaippn_' . $i;
                $tglbayar = 'tglbayarPegawai_' . $i;
                $total = 'totalPegawai_' . $i;
                $statusPembiyaan = 'statusPembiyaanPegawai_' . $i;
                DB::table('keuangan_perjadinkegiatans')
                ->where('perangkat_acara', $request->$idPerangkatAcara)
                ->update([
                    'harga' => $request->$nominal,
                    'persen_pajak' => $request->$pajak,
                    'pph22' => $request->$pph22,
                    'pph23' => $request->$pph23,
                    'ppn' => $request->$ppn,
                    'tgl_bayar' => $request->$tglbayar,
                    'jumlah_harga' => $request->$total,
                    'ref_sbm' => $request->$sbm,
                    'akun_x_rkakl' => $request->$akun,
                    'status' => $request->$statusPembiyaan,
                    'updated_at' => now()->format('Y-m-d H:i:s'),
                ]);
            }

            $nonPegawaiTotal = $request->numNonPegawai;
            for ($j=0; $j < $nonPegawaiTotal; $j++) { 
                $idPerangkatAcaraNonPegawai = 'idPerangkatNonPegawai_' . $j;
                $akunNonPegawai = 'akunNonPegawai_' . $j;
                $sbmNonPegawai = 'sbmNonPegawai_' . $j;
                $nominalNonPegawai = 'nominalNonPegawai_' . $j;
                $pajakNonPegawai = 'pajakNonPegawai_' . $j;
                $pajakNonPegawaipph22 = 'pajakNonPegawaipph22_' . $j;
                $pajakNonPegawaipph23 = 'pajakNonPegawaipph23_' . $j;
                $pajakNonPegawaippn = 'pajakNonPegawaippn_' . $j;
                $totalNonPegawaitglbayar = 'tglbayarNonPegawai_' . $j;
                $totalNonPegawai = 'totalNonPegawai_' . $j;
                $statusPembiyaanNonPegawai = 'statusPembayaranNonPegawai_' . $j;
                DB::table('keuangan_perjadinkegiatans')
                ->where('perangkat_acara', $request->$idPerangkatAcaraNonPegawai)
                ->update([
                    'harga' => $request->$nominalNonPegawai,
                    'persen_pajak' => $request->$pajakNonPegawai,
                    'pph22' => $request->$pajakNonPegawaipph22,
                    'pph23' => $request->$pajakNonPegawaipph23,
                    'ppn' => $request->$pajakNonPegawaippn,
                    'tgl_bayar' => $request->$totalNonPegawaitglbayar,
                    'jumlah_harga' => $request->$totalNonPegawai,
                    'ref_sbm' => $request->$sbmNonPegawai,
                    'akun_x_rkakl' => $request->$akunNonPegawai,
                    'status' => $request->$statusPembiyaanNonPegawai,
                    'updated_at' => now()->format('Y-m-d H:i:s'),
                ]);
            }

            $numOperasionalBend = $request->numOperasional;
            for ($j=0; $j < $numOperasionalBend; $j++) { 
                $idOperasional = 'idOperasional_' . $j;
                $akunOperasional = 'akunOperasional_' . $j;
                $sbmOperasional = 'sbmOperasional_' . $j;
                $nominalOperasional = 'nominalOperasional_' . $j;
                $pajakOperasional = 'pajakOperasional_' . $j;
                $pajakOperasional22 = 'pajakOperasionalpph22_' . $j;
                $pajakOperasional23 = 'pajakOperasionalpph23_' . $j;
                $pajakOperasionalppn = 'pajakOperasionalppn_' . $j;
                $totalOperasionaltglbayar = 'tglbayarOperasional_' . $j;
                $totalOperasional = 'totalOperasional_' . $j;
                $statusOperasional = 'kesesuaianOperasional_' . $j;
                DB::table('keuangan_perjadinkegiatans')
                ->where('operasional', $request->$idOperasional)
                ->update([
                    'harga' => $request->$nominalOperasional,
                    'persen_pajak' => $request->$pajakOperasional,
                    'pph22' => $request->$pajakOperasional22,
                    'pph23' => $request->$pajakOperasional23,
                    'ppn' => $request->$pajakOperasionalppn,
                    'tgl_bayar' => $request->$totalOperasionaltglbayar,
                    'jumlah_harga' => $request->$totalOperasional,
                    'ref_sbm' => $request->$sbmOperasional,
                    'akun_x_rkakl' => $request->$akunOperasional,
                    'status' => $request->$statusOperasional,
                    'updated_at' => now()->format('Y-m-d H:i:s'),
                ]);
            }

            DB::table('data_perjadinkegiatans')
                ->where('id', $request->idKegiatan)
                ->update([
                    'status' => 'proses',
                    'is_acceptKeu' => 'verifikasi-2',
                    'admin_Bend' => auth('administrator')->user()->id,
                    'updated_at' => now()->format('Y-m-d H:i:s'),
                ]);

            return redirect()->route('bendahara-kegiatan', ['status' => 'approval-2'])->with('success', 'Data telah diperbaharui!, anda telah menyetujui kegiatan.');

        } elseif($action === 'approve-2') {

            $totalpegawai = $request->numPegawai;
            for ($i=0; $i < $totalpegawai; $i++) { 
                $idPerangkatAcara = 'idPerangkatPegawai_' . $i;
                $akun = 'akunPegawai_' . $i;
                $sbm = 'sbmPegawai_' . $i;
                $nominal = 'nominalPegawai_' . $i;
                $pajak = 'pajakPegawai_' . $i;
                $pph22 = 'pajakPegawaipph22_' . $i;
                $pph23 = 'pajakPegawaipph23_' . $i;
                $ppn = 'pajakPegawaippn_' . $i;
                $tglbayar = 'tglbayarPegawai_' . $i;
                $total = 'totalPegawai_' . $i;
                $statusPembiyaan = 'statusPembiyaanPegawai_' . $i;
                DB::table('keuangan_perjadinkegiatans')
                ->where('perangkat_acara', $request->$idPerangkatAcara)
                ->update([
                    'harga' => $request->$nominal,
                    'persen_pajak' => $request->$pajak,
                    'pph22' => $request->$pph22,
                    'pph23' => $request->$pph23,
                    'ppn' => $request->$ppn,
                    'tgl_bayar' => $request->$tglbayar,
                    'jumlah_harga' => $request->$total,
                    'ref_sbm' => $request->$sbm,
                    'akun_x_rkakl' => $request->$akun,
                    'status' => $request->$statusPembiyaan,
                    'updated_at' => now()->format('Y-m-d H:i:s'),
                ]);
            }

            $nonPegawaiTotal = $request->numNonPegawai;
            for ($j=0; $j < $nonPegawaiTotal; $j++) { 
                $idPerangkatAcaraNonPegawai = 'idPerangkatNonPegawai_' . $j;
                $akunNonPegawai = 'akunNonPegawai_' . $j;
                $sbmNonPegawai = 'sbmNonPegawai_' . $j;
                $nominalNonPegawai = 'nominalNonPegawai_' . $j;
                $pajakNonPegawai = 'pajakNonPegawai_' . $j;
                $pajakNonPegawaipph22 = 'pajakNonPegawaipph22_' . $j;
                $pajakNonPegawaipph23 = 'pajakNonPegawaipph23_' . $j;
                $pajakNonPegawaippn = 'pajakNonPegawaippn_' . $j;
                $totalNonPegawaitglbayar = 'tglbayarNonPegawai_' . $j;
                $totalNonPegawai = 'totalNonPegawai_' . $j;
                $statusPembiyaanNonPegawai = 'statusPembayaranNonPegawai_' . $j;
                DB::table('keuangan_perjadinkegiatans')
                ->where('perangkat_acara', $request->$idPerangkatAcaraNonPegawai)
                ->update([
                    'harga' => $request->$nominalNonPegawai,
                    'persen_pajak' => $request->$pajakNonPegawai,
                    'pph22' => $request->$pajakNonPegawaipph22,
                    'pph23' => $request->$pajakNonPegawaipph23,
                    'ppn' => $request->$pajakNonPegawaippn,
                    'tgl_bayar' => $request->$totalNonPegawaitglbayar,
                    'jumlah_harga' => $request->$totalNonPegawai,
                    'ref_sbm' => $request->$sbmNonPegawai,
                    'akun_x_rkakl' => $request->$akunNonPegawai,
                    'status' => $request->$statusPembiyaanNonPegawai,
                    'updated_at' => now()->format('Y-m-d H:i:s'),
                ]);
            }

            $numOperasionalBend = $request->numOperasional;
            for ($j=0; $j < $numOperasionalBend; $j++) { 
                $idOperasional = 'idOperasional_' . $j;
                $akunOperasional = 'akunOperasional_' . $j;
                $sbmOperasional = 'sbmOperasional_' . $j;
                $nominalOperasional = 'nominalOperasional_' . $j;
                $pajakOperasional = 'pajakOperasional_' . $j;
                $pajakOperasional22 = 'pajakOperasionalpph22_' . $j;
                $pajakOperasional23 = 'pajakOperasionalpph23_' . $j;
                $pajakOperasionalppn = 'pajakOperasionalppn_' . $j;
                $totalOperasionaltglbayar = 'tglbayarOperasional_' . $j;
                $totalOperasional = 'totalOperasional_' . $j;
                $statusOperasional = 'kesesuaianOperasional_' . $j;
                DB::table('keuangan_perjadinkegiatans')
                ->where('operasional', $request->$idOperasional)
                ->update([
                    'harga' => $request->$nominalOperasional,
                    'persen_pajak' => $request->$pajakOperasional,
                    'pph22' => $request->$pajakOperasional22,
                    'pph23' => $request->$pajakOperasional23,
                    'ppn' => $request->$pajakOperasionalppn,
                    'tgl_bayar' => $request->$totalOperasionaltglbayar,
                    'jumlah_harga' => $request->$totalOperasional,
                    'ref_sbm' => $request->$sbmOperasional,
                    'akun_x_rkakl' => $request->$akunOperasional,
                    'status' => $request->$statusOperasional,
                    'updated_at' => now()->format('Y-m-d H:i:s'),
                ]);
            }

            DB::table('data_perjadinkegiatans')
                ->where('id', $request->idKegiatan)
                ->update([
                    'status' => 'selesai',
                    'is_acceptKeu' => 'selesai',
                    'is_acceptBend' => 'selesai',
                    'admin_Bend' => auth('administrator')->user()->id,
                    'updated_at' => now()->format('Y-m-d H:i:s'),
                ]);

            return redirect()->route('bendahara-kegiatan', ['status' => 'selesai'])->with('success', 'Data telah diperbaharui!, Kegiatan sudah disetujui untuk selesai.');

        } elseif($action === 'simpan') {

            $totalpegawai = $request->numPegawai;
            for ($i=0; $i < $totalpegawai; $i++) { 
                $idPerangkatAcara = 'idPerangkatPegawai_' . $i;
                $akun = 'akunPegawai_' . $i;
                $sbm = 'sbmPegawai_' . $i;
                $nominal = 'nominalPegawai_' . $i;
                $pajak = 'pajakPegawai_' . $i;
                $pph22 = 'pajakPegawaipph22_' . $i;
                $pph23 = 'pajakPegawaipph23_' . $i;
                $ppn = 'pajakPegawaippn_' . $i;
                $tglbayar = 'tglbayarPegawai_' . $i;
                $total = 'totalPegawai_' . $i;
                $statusPembiyaan = 'statusPembiyaanPegawai_' . $i;
                DB::table('keuangan_perjadinkegiatans')
                ->where('perangkat_acara', $request->$idPerangkatAcara)
                ->update([
                    'harga' => $request->$nominal,
                    'persen_pajak' => $request->$pajak,
                    'pph22' => $request->$pph22,
                    'pph23' => $request->$pph23,
                    'ppn' => $request->$ppn,
                    'tgl_bayar' => $request->$tglbayar,
                    'jumlah_harga' => $request->$total,
                    'ref_sbm' => $request->$sbm,
                    'akun_x_rkakl' => $request->$akun,
                    'status' => $request->$statusPembiyaan,
                    'updated_at' => now()->format('Y-m-d H:i:s'),
                ]);
            }

            $nonPegawaiTotal = $request->numNonPegawai;
            for ($j=0; $j < $nonPegawaiTotal; $j++) { 
                $idPerangkatAcaraNonPegawai = 'idPerangkatNonPegawai_' . $j;
                $akunNonPegawai = 'akunNonPegawai_' . $j;
                $sbmNonPegawai = 'sbmNonPegawai_' . $j;
                $nominalNonPegawai = 'nominalNonPegawai_' . $j;
                $pajakNonPegawai = 'pajakNonPegawai_' . $j;
                $pajakNonPegawaipph22 = 'pajakNonPegawaipph22_' . $j;
                $pajakNonPegawaipph23 = 'pajakNonPegawaipph23_' . $j;
                $pajakNonPegawaippn = 'pajakNonPegawaippn_' . $j;
                $totalNonPegawaitglbayar = 'tglbayarNonPegawai_' . $j;
                $totalNonPegawai = 'totalNonPegawai_' . $j;
                $statusPembiyaanNonPegawai = 'statusPembayaranNonPegawai_' . $j;
                DB::table('keuangan_perjadinkegiatans')
                ->where('perangkat_acara', $request->$idPerangkatAcaraNonPegawai)
                ->update([
                    'harga' => $request->$nominalNonPegawai,
                    'persen_pajak' => $request->$pajakNonPegawai,
                    'pph22' => $request->$pajakNonPegawaipph22,
                    'pph23' => $request->$pajakNonPegawaipph23,
                    'ppn' => $request->$pajakNonPegawaippn,
                    'tgl_bayar' => $request->$totalNonPegawaitglbayar,
                    'jumlah_harga' => $request->$totalNonPegawai,
                    'ref_sbm' => $request->$sbmNonPegawai,
                    'akun_x_rkakl' => $request->$akunNonPegawai,
                    'status' => $request->$statusPembiyaanNonPegawai,
                    'updated_at' => now()->format('Y-m-d H:i:s'),
                ]);
            }

            $numOperasionalBend = $request->numOperasional;
            for ($j=0; $j < $numOperasionalBend; $j++) { 
                $idOperasional = 'idOperasional_' . $j;
                $akunOperasional = 'akunOperasional_' . $j;
                $sbmOperasional = 'sbmOperasional_' . $j;
                $nominalOperasional = 'nominalOperasional_' . $j;
                $pajakOperasional = 'pajakOperasional_' . $j;
                $pajakOperasional22 = 'pajakOperasionalpph22_' . $j;
                $pajakOperasional23 = 'pajakOperasionalpph23_' . $j;
                $pajakOperasionalppn = 'pajakOperasionalppn_' . $j;
                $totalOperasionaltglbayar = 'tglbayarOperasional_' . $j;
                $totalOperasional = 'totalOperasional_' . $j;
                $statusOperasional = 'kesesuaianOperasional_' . $j;
                DB::table('keuangan_perjadinkegiatans')
                ->where('operasional', $request->$idOperasional)
                ->update([
                    'harga' => $request->$nominalOperasional,
                    'persen_pajak' => $request->$pajakOperasional,
                    'pph22' => $request->$pajakOperasional22,
                    'pph23' => $request->$pajakOperasional23,
                    'ppn' => $request->$pajakOperasionalppn,
                    'tgl_bayar' => $request->$totalOperasionaltglbayar,
                    'jumlah_harga' => $request->$totalOperasional,
                    'ref_sbm' => $request->$sbmOperasional,
                    'akun_x_rkakl' => $request->$akunOperasional,
                    'status' => $request->$statusOperasional,
                    'updated_at' => now()->format('Y-m-d H:i:s'),
                ]);
            }

            return redirect()->route('bendahara-kegiatan', ['status' => 'approval-2'])->with('success', 'Data telah diperbaharui!, Kegiatan sudah disetujui untuk selesai.');

        } elseif($action === 'revisi') {
            DB::table('data_perjadinkegiatans')
                ->where('id', $request->idKegiatan)
                ->update([
                    'status' => 'revisi',
                    'is_acceptKeu' => 'verifikasi-1',
                    'is_acceptBend' => 'revisi',
                    'admin_Bend' => auth('administrator')->user()->id,
                    'updated_at' => now()->format('Y-m-d H:i:s'),
                ]);

            return redirect()->route('bendahara-kegiatan', ['status' => 'revisi'])->with('success', 'Data telah diperbaharui!, Konfirmasi ulang kebagian keuangan!');
        } elseif($action === 'tolak') {
            $idMobilitas = DB::table('mobilitas_perjadinkegiatans')
                    ->where('data_perjadinkegiatan', $request->idKegiatan)
                    ->select('id')
                    ->first();

            DB::table('peminjaman_kendaraan_dinas')
                        ->where('mobilitas_perjadinkegiatan', $idMobilitas->id)
                        ->update([
                            'status' => 'ditolak',
                            'updated_at' => now()->format('Y-m-d H:i:s'),
                        ]);
            
            DB::table('mobilitas_perjadinkegiatans')
                        ->where('data_perjadinkegiatan', $request->idKegiatan)
                        ->update([
                            'status' => 'ditolak',
                            'updated_at' => now()->format('Y-m-d H:i:s'),
                        ]);
                        
            DB::table('data_perjadinkegiatans')
                ->where('id', $request->idKegiatan)
                ->update([
                    'status' => 'ditolak',
                    'is_acceptKeu' => 'verifikasi-1',
                    'is_acceptBend' => 'ditolak',
                    'admin_Bend' => auth('administrator')->user()->id,
                    'updated_at' => now()->format('Y-m-d H:i:s'),
                ]);

            return redirect()->route('bendahara-kegiatan', ['status' => 'ditolak'])->with('success', 'Data telah diperbaharui!, Kegiatan telah anda ditolak!');
        }
        
    }

    public function AdmingetDokumen($filename)
    {
        $path = storage_path('app/public/dokumen-kegiatans/' . $filename);
        if (!file_exists($path)) {
            abort(404);
        }
        return response()->file($path);
    }

    public function updateSapras(Request $request)
    {
        $total = $request->total;
        for ($i=0; $i < $total; $i++) { 
            $idPeminjaman = 'idPeminjaman_' . $i;
            $idBarang = 'idBarang_' . $i;
            $status = 'status_' . $i;
            DB::table('peminjaman_sarpras')
                ->where('id', $request->$idPeminjaman)
                ->update([
                    'status' => $request->$status,
                    'updated_at' => now()->format('Y-m-d H:i:s'),
                ]);
            if ($request->$status == 'digunakan') {
                DB::table('assets')
                ->where('id', $request->$idBarang)
                ->update([
                    'status_peminjaman' => 'digunakan',
                    'updated_at' => now()->format('Y-m-d H:i:s'),
                ]);
            }

            if ($request->$status == 'selesai') {
                DB::table('assets')
                ->where('id', $request->$idBarang)
                ->update([
                    'status_peminjaman' => 'tidak digunakan',
                    'updated_at' => now()->format('Y-m-d H:i:s'),
                ]);
            }
        }
        return redirect()->route('sapras', ['status' => 'proses'])->with('success', 'Data telah diperbaharui!');

    }

  

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }

    public function tolakKegiatan(Request $request)
{
    // Validasi input
    $request->validate([
        'alasan' => 'required|string|max:255',
        'idKegiatan' => 'required|exists:data_perjadinkegiatans,id',
    ]);

    try {
        DB::beginTransaction();

        $idMoblitas = DB::table('mobilitas_perjadinkegiatans')
                    ->where('data_perjadinkegiatan', $request->idKegiatan)
                    ->select('id')
                    ->first();

        DB::table('peminjaman_kendaraan_dinas')
                    ->where('mobilitas_perjadinkegiatan', $idMobilitas->id)
                    ->update([
                        'status' => 'ditolak',
                        'updated_at' => now()->format('Y-m-d H:i:s'),
                    ]);
        
        DB::table('mobilitas_perjadinkegiatans')
                    ->where('data_perjadinkegiatan', $request->idKegiatan)
                    ->update([
                        'status' => 'ditolak',
                        'updated_at' => now()->format('Y-m-d H:i:s'),
                    ]);

        // Update status kegiatan menjadi ditolak
        DB::table('data_perjadinkegiatans')
            ->where('id', $request->idKegiatan)
            ->update([
                'status_pengajuan' => 'ditolak',
                'status_pengajuan_detail' => 'Verifikasi-HKT-ditolak',
                'is_acceptHKT' => 'ditolak',
                'alasan_penolakan' => $request->alasan,
                'updated_at' => now()->format('Y-m-d H:i:s'),
            ]);

        // Update status perangkat_acaras menjadi ditolak
        DB::table('perangkat_acaras')
            ->where('data_perjadin_kegiatan', $request->idKegiatan)
            ->update([
                'status' => 'ditolak',  // Set status menjadi ditolak
                'updated_at' => now()->format('Y-m-d H:i:s'),
            ]);

        DB::commit();
        return redirect()->route('HKT-kegiatan', ['status' => 'pengajuan'])->with('success', 'Pengajuan Telah Berhasil Ditolak!');
    } catch (\Exception $e) {
        DB::rollBack();
        return back()->with('error', 'Gagal menolak pengajuan: ' . $e->getMessage());
    }
}


public function uploadSuratKegiatan(Request $request)
{
    // Validasi input
    $request->validate([
        'surat_tugas' => 'required|mimes:pdf|file|max:2048', // Harus file PDF
    ]);

    // Ambil ID kegiatan
    $id = $request->input('idKegiatan');

    if (!$id) {
        return back()->with('error', 'Data kegiatan tidak ditemukan.');
    }

    // Cari data kegiatan
    $kegiatan = DB::table('data_perjadinkegiatans')->where('id', $id)->first();
    if (!$kegiatan) {
        return back()->with('error', 'Data kegiatan tidak ditemukan.');
    }

    try {
        DB::beginTransaction();

        // Simpan file PDF surat tugas
        $filePath = $request->file('surat_tugas')->store('dokumens-kegiatans', 'public');

        // Update tabel dengan path surat tugas baru
        DB::table('data_perjadinkegiatans')
            ->where('id', $id)
            ->update([
                'surat_tugas' => $filePath,
                'updated_at' => now()->format('Y-m-d H:i:s'),
            ]);

        DB::commit();
        return redirect()->route('HKT-kegiatan', ['status' => 'selesai'])->with('success', 'Surat Tugas telah berhasil diupload!');
    } catch (\Exception $e) {
        DB::rollBack();
        return back()->with('error', 'Gagal mengupload surat tugas: ' . $e->getMessage());
    }
}

public function updateSuratKegiatan(Request $request)
{
    // Validasi input surat tugas
    $request->validate([
        'surat_tugas_update' => 'required|mimes:pdf|file|max:2048',
        'nomor_surtug_update' => 'required',
        'tgl_dibuat_update' => 'required|date',
    ]);

    // Ambil ID kegiatan dari input
    $id = $request->input('idKegiatanUpdate');
    if (!$id) {
        return back()->with('error', 'Data kegiatan tidak ditemukan.');
    }

    // Cari kegiatan berdasarkan ID
    $kegiatan = DB::table('data_perjadinkegiatans')->where('id', $id)->first();
    if (!$kegiatan) {
        return back()->with('error', 'Data kegiatan tidak ditemukan.');
    }

    try {
        DB::beginTransaction();

        // Simpan file PDF surat tugas
        $filePath = $request->file('surat_tugas_update')->store('dokumen-kegiatans', 'public');

        // Update data dokumen dan kegiatan di database
        DB::table('dokumens')
            ->where('data_perjadinkegiatan_id', $id)
            ->update([
                'surat_tugas' => $filePath,
                'updated_at' => now()->format('Y-m-d H:i:s'),
            ]);

        DB::table('data_perjadinkegiatans')
            ->where('id', $id)
            ->update([
                'kode_surat_tugas' => $request->nomor_surtug_update,
                'updated_at' => now()->format('Y-m-d H:i:s'),
            ]);

        DB::table('perangkat_acaras')
            ->where('data_perjadinkegiatan_id', $id)
            ->update([
                'nomor_surat' => $request->nomor_surtug_update,
                'tgl_surat_dibuat' => $request->tgl_dibuat_update,
                'updated_at' => now()->format('Y-m-d H:i:s'),
            ]);

        DB::commit();
        return redirect()->route('HKT-kegiatan', ['status' => 'selesai'])->with('success', 'Surat Tugas telah berhasil diupdate!');
    } catch (\Exception $e) {
        DB::rollBack();
        return back()->with('error', 'Gagal mengupdate surat tugas: ' . $e->getMessage());
    }
}

public function deleteMobilitas(Request $request, $id)
    {
        DB::table('peminjaman_kendaraan_dinas')->where('id', $id)->delete();

        // Mendapatkan ID perjadin dari request JSON
        $id_kegiatan = $request->input('mobilitas_perjadinkegiatan');

        // Mengembalikan response sukses
        return response()->json(['success' => true]);
    }

public function uploadTTEPerjadinKegiatan(Request $request)
{
    $id = $request->input('idKegiatan'); // 'id' sesuai dengan parameter dalam URL
        if (!$id) {
            dd('Data tidak ditemukan.');
        }
        $perjadin = DB::table('data_perjadinkegiatans')->where('id', $id)->first();
        if (!$perjadin) {
            dd('Data tidak ditemukan.');
        }
        
        DB::table('surtug_perjadinkegiatans')
            ->where('data_Perjadin_kegiatan', $id)
            ->update([
                'nomor_surat' => $request->nomor_surtug_tte,
                'tgl_surat_dibuat' => $request->tgl_dibuat_tte,
                'updated_at' => now()->format('Y-m-d H:i:s'),
            ]);


        return redirect()->route('HKT-kegiatan', ['status' => 'pengajuan'])->with('success', 'Surat Tugas telah berhasil di Upload!');
}

public function ganerateLaporanHKT(Request $request)
    {
        $mulai = $request->tanggalDari;
        $sampai = $request->tanggalSampai;
        return redirect()->route('laporan-HKT-kegiatan', ['mulai' => $mulai, 'sampai' => $sampai])->with('success', 'Data Telah diset!');
    }

    public function getAllDataHKT($mulai, $sampai)
{
    // Ambil semua data dari tabel
    $data = DB::table('data_perjadinkegiatans')
     ->select(
         'data_perjadinkegiatans.id AS id_kegiatan',
         'data_perjadinkegiatans.nama_kegiatan',
         'data_perjadinkegiatans.tgl_mulai',
         'data_perjadinkegiatans.tgl_selesai',
         'data_perjadinkegiatans.alamat',
         'data_perjadinkegiatans.kab_kota',
         'data_perjadinkegiatans.provinsi',
         'data_perjadinkegiatans.id_pengaju',
         'surtug_perjadinkegiatans.nomor_surat AS no_surtug',
         'surtug_perjadinkegiatans.tgl_surat_dibuat AS tgl_surtug',
         'data_perjadinkegiatans.is_acceptHKT',
         'data_perjadinkegiatans.status_pengajuan_detail',
         DB::raw('COALESCE(CONCAT("(Admin) ", administrators.username), pegawais.nama_lengkap, non_pegawais.nama_lengkap, "Tidak ditemukan") as nama_pengaju'),
         // Subquery to get the list of participants (nama_peserta)
         DB::raw("(SELECT GROUP_CONCAT(COALESCE(pegawais.nama_lengkap, non_pegawais.nama_lengkap) SEPARATOR '\n') 
                   FROM perangkat_acaras 
                   LEFT JOIN pegawais ON perangkat_acaras.pegawai_id = pegawais.id 
                   LEFT JOIN non_pegawais ON perangkat_acaras.non_pegawai_id = non_pegawais.id 
                   WHERE perangkat_acaras.data_perjadin_kegiatan = data_perjadinkegiatans.id) AS nama_peserta")
     )
     ->leftJoin('perangkat_acaras', 'perangkat_acaras.data_perjadin_kegiatan', '=', 'data_perjadinkegiatans.id')
     ->leftJoin('surtug_perjadinkegiatans', 'surtug_perjadinkegiatans.data_perjadin_kegiatan', '=', 'data_perjadinkegiatans.id')
     ->leftJoin('administrators', 'data_perjadinkegiatans.id_pengaju', '=', 'administrators.id')
     ->leftJoin('pegawais', 'data_perjadinkegiatans.id_pengaju', '=', 'pegawais.id')
     ->leftJoin('non_pegawais', 'data_perjadinkegiatans.id_pengaju', '=', 'non_pegawais.id')
     ->whereBetween('data_perjadinkegiatans.tgl_mulai', [$mulai, $sampai])
     ->whereNotNull('data_perjadinkegiatans.is_acceptHKT')
     ->where('data_perjadinkegiatans.is_acceptHKT', '<>', 'ditolak')
     ->get();

    return response()->json($data);
}

    
    public function laporanHKT($mulai, $sampai)
{
    // Mengambil data kegiatan yang relevan dengan join ke tabel surtug_perjadinkegiatans
    $data = DB::table('data_perjadinkegiatans')
        ->select(
            'data_perjadinkegiatans.id AS id_kegiatan',
            'data_perjadinkegiatans.nama_kegiatan',
            'data_perjadinkegiatans.tgl_mulai',
            'data_perjadinkegiatans.tgl_selesai',
            'data_perjadinkegiatans.alamat',
            'data_perjadinkegiatans.kab_kota',
            'data_perjadinkegiatans.provinsi',
            'data_perjadinkegiatans.kode_surat_tugas AS no_surtug',
            // Mengambil tgl_surat_dibuat dari tabel surtug_perjadinkegiatans
            'surtug_perjadinkegiatans.tgl_surat_dibuat AS tgl_surtug',
            'data_perjadinkegiatans.is_acceptHKT',
            'data_perjadinkegiatans.status_pengajuan_detail',
            DB::raw('COALESCE(pegawais.nama_lengkap, "Tidak ditemukan") as nama_pengaju'),
            DB::raw("(SELECT GROUP_CONCAT(COALESCE(pegawais.nama_lengkap, non_pegawais.nama_lengkap) SEPARATOR '\n') 
                   FROM perangkat_acaras 
                   LEFT JOIN pegawais ON perangkat_acaras.pegawai_id = pegawais.id 
                   LEFT JOIN non_pegawais ON perangkat_acaras.non_pegawai_id = non_pegawais.id 
                   WHERE perangkat_acaras.data_perjadin_kegiatan = data_perjadinkegiatans.id) AS nama_peserta")
    
        )
        ->leftJoin('perangkat_acaras', 'perangkat_acaras.data_perjadin_kegiatan', '=', 'data_perjadinkegiatans.id')
        ->leftJoin('surtug_perjadinkegiatans', 'surtug_perjadinkegiatans.data_perjadin_kegiatan', '=', 'data_perjadinkegiatans.id')
        ->leftJoin('administrators', 'data_perjadinkegiatans.id_pengaju', '=', 'administrators.id')
        ->leftJoin('pegawais', 'data_perjadinkegiatans.id_pengaju', '=', 'pegawais.id')
        ->leftJoin('non_pegawais', 'data_perjadinkegiatans.id_pengaju', '=', 'non_pegawais.id')
        ->whereBetween('data_perjadinkegiatans.tgl_mulai', [$mulai, $sampai])
        ->whereNotNull('data_perjadinkegiatans.is_acceptHKT')
        ->where('data_perjadinkegiatans.is_acceptHKT', '<>', 'ditolak')
        ->groupBy()
        ->get();

    return view('admin.kegiatan.HKT.LaporanHKT', compact('data', 'mulai', 'sampai'));
}
}
